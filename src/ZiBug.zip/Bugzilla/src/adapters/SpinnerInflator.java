package adapters;

import java.util.List;

import org.elsys.R;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

/**
 * Defines operations for selecting the data in a Spinner and inflating a
 * Spinner <li>
 * {@link #setSelection(Object, String)} <li>
 * {@link #inflateSpinner(Spinner, List, Context)}
 */
public class SpinnerInflator {

	/**
	 * Selects the item to show on the Spinner from the data in the Spinner and
	 * the given item
	 * 
	 * @param spinner
	 *            the Spinner to select from
	 * @param item
	 *            the item which should be shown
	 */
	public static void setSelection(Spinner spinner, String item) {
		for (int i = 0; i < spinner.getCount(); i++) {
			if (spinner.getItemAtPosition(i).equals(item)) {
				spinner.setSelection(i);
				break;
			}
		}
	}

	/**
	 * Inflates the given Spinner with a list of items
	 * 
	 * @param spinner the inflated Spinner
	 * @param data the data to be inflated
	 * @param context the Activity Context
	 */
	public static <E> void inflateSpinner(Spinner spinner, List<E> data,
			Context context) {
		ArrayAdapter<E> adapter = new ArrayAdapter<E>(context,
				android.R.layout.simple_spinner_item, data);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
		spinner.setAdapter(adapter);
	}
}
