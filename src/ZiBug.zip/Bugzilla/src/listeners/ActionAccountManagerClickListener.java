package listeners;

import android.content.Context;
import android.content.Intent;
import android.view.View;

/**
 * Click listener for the Account Manager action item
 * 
 * @extends {@link ActionItemClickListener}
 */
public class ActionAccountManagerClickListener extends ActionItemClickListener {

	/**
	 * Constructs new {@link ActionAccountManagerClickListener}
	 * 
	 * @param context the Activity Context
	 */
	public ActionAccountManagerClickListener(Context context) {
		super(context);
	}

	@Override
	public void onClick(View v) {
		intent = new Intent(context, org.elsys.AccountManager.class);
		context.startActivity(intent);
	}

}
