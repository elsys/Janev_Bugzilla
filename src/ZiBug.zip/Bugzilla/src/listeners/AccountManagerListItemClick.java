package listeners;

import org.elsys.data.Account;
import org.elsys.data.App;
import org.elsys.utilities.AccountConfigurationPersistor;
import org.elsys.utilities.AccountPersistor;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

public class AccountManagerListItemClick implements OnItemClickListener {

	private Context context;

	public AccountManagerListItemClick(Context context) {
		this.context = context;
	}
	
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		Account currentAcc = (Account) arg0.getItemAtPosition(arg2);
		currentAcc.setAccountConfiguration(AccountConfigurationPersistor
				.getConfiguration(context, currentAcc.getAccountId()));
		App.get().setAccount(currentAcc);
		AccountPersistor.persistCurrentAccount(context,
				currentAcc.getAccountId());

		Intent intent = new Intent(context, org.elsys.Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		context.startActivity(intent);
	}

}
