package org.elsys.requests;


import org.codehaus.jackson.map.ser.FilterProvider;
import org.codehaus.jackson.map.ser.impl.SimpleBeanPropertyFilter;
import org.codehaus.jackson.map.ser.impl.SimpleFilterProvider;
import org.elsys.BugComprehensiveView;
import org.elsys.R;
import org.elsys.data.Bug;

import android.content.Context;

public class BugPutRequest extends BugzillaHttpPostPutRequest {

	private Bug bug;

	public BugPutRequest(Context context, Bug bug) {
		super(context, context.getString(R.string.bug_post_message), context
				.getString(R.string.http_put), bug);

		this.bug = bug;

		FilterProvider filters = new SimpleFilterProvider().addFilter(
				"bugFilter", SimpleBeanPropertyFilter.serializeAllExcept("comments"));
		mapper.setFilters(filters);
		
		execute("bug/" + bug.getId());
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		if (!error) {
			new BugTokenRequest(context, bug);
		} else if(sendTimeOut == 0) {
			((BugComprehensiveView) context).notifyError();
		}
	}
}
