package org.elsys.requests;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.elsys.BugzillaActivity;
import org.elsys.R;
import org.elsys.data.AccountConfiguration;
import org.elsys.dialogs.LoginDialog;
import org.elsys.parser.ParseStreamJson;
import org.elsys.utilities.AccountConfigurationPersistor;
import org.elsys.utilities.AccountPersistor;

import android.content.Context;

public class AccountConfigurationRequest extends BugzillaHttpGetRequest {

	private AccountConfiguration accountConfiguration;

	private LoginDialog dialog;

	public AccountConfigurationRequest(Context context, LoginDialog dialog) {
		super(context, context.getString(R.string.configuration_message));

		this.dialog = dialog;
		execute("configuration");
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (!error) {
			AccountPersistor.persistAccount(context, account);
			AccountPersistor.persistCurrentAccount(context,
					account.getAccountId());
			AccountConfigurationPersistor.persistConfiguration(context,
					account.getAccountId(), accountConfiguration);
			account.setAccountConfiguration(accountConfiguration);
			if (dialog != null) {
				dialog.proccessResponse();
			}
		}

	}

	@Override
	protected void processStream(org.codehaus.jackson.JsonParser jParser)
			throws IOException, JsonParseException {
		accountConfiguration = ParseStreamJson.readAccountConfiguration(jParser);
	}
}
