package adapters;

/**
 * Defines operations for inflating, making selections and setting listeners to
 * Spinner views <li>
 * {@link #inflateSpinners()} <li>
 * {@link #setSelections()} <li>
 * {@link #setListeners()}
 */
public interface SpinnerAdapter {

	/** Inflates the corresponding Spinner views */
	public void inflateSpinners();

	/** Chooses the right selections for the Spinner views */
	public void setSelections();

	/**
	 * Setting listeners for the corresponding Spinner views or in some cases
	 * for Button views as well
	 */
	public void setListeners();
}
