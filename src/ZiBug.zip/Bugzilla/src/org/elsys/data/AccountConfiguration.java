package org.elsys.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

public class AccountConfiguration {
	private List<String> platformHardwareList, platformOSList, priorities,
			severities, resolution;

	private List<Status> statuses = new ArrayList<Status>();
	private List<Product> products = new ArrayList<Product>();
	private HashMap<String, List<Status>> statusMap;
	
	public AccountConfiguration() {
		platformHardwareList = new ArrayList<String>();
		platformOSList = new ArrayList<String>();
		priorities = new ArrayList<String>();
		severities = new ArrayList<String>();
		resolution = new ArrayList<String>();
		statusMap = new HashMap<String, List<Status>>();
	}

	public List<Status> getStatuses() {
		return statuses;
	}
	
	public void setStatuses(List<Status> statuses) {
		this.statuses = statuses;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public HashMap<String, List<Status>> getStatusMap() {
		return statusMap;
	}
	
	public void setStatusMap(HashMap<String, List<Status>> statusMap) {
		this.statusMap = statusMap;
	}
	
	public void setTransitionsForStatus(String statusName,
			List<Status> transitions) {
		for(Status status : statuses) {
			if(statusName.equals(status.getStatus())) {
				for (Status transition : transitions) {
					for (Status s : statuses) {
						if (transition.getStatus().equals(s.getStatus())) {
							transition.setStatusType(s.getStatusType());
						}
					}
					status.addTransition(transition);
				}
			}
		}
		
	}

	public void removeInitialValues(List<Status> initialValues) {
		Iterator<Status> iterator;
		Status transition;
		
		for(Status status : statuses) {
			iterator = status.getTransitions().iterator();
				while(iterator.hasNext()) {
					transition = iterator.next();
					for(Status value : initialValues) {
						if(value.getStatus().equals(transition.getStatus()) && !status.getStatus().equals(value.getStatus())) {
							iterator.remove();
						}
					}
			}
		}
	}
	
	public List<Status> getTransitionsForStatus(String statusName) {
		for (Status s : statuses) {
			if (statusName.equals(s.getStatus())) {
				return s.getTransitions();
			}
		}
		return null;
	}

	@JsonIgnore
	public List<Status> getStatuses(String type) {
		if ("All".equals(type)) {
			return new ArrayList<Status>();
		}
		return statusMap.get(type);
	}

	public void addStatus(Status status) {
		statuses.add(status);
	}

	public void addStatusToMap(String type, List<Status> statuses) {
		statusMap.put(type, statuses);
	}
	
	public List<Product> getProducts() {
		return products;
	}

	public Product getProductByName(String productName) {
		for(Product p : products) {
			if(productName.equals(p.getProductName())) {
				return p;
			}
		}
		return null;
	}
	
	public void addProduct(Product product) {
		products.add(product);
	}

	public List<String> getPlatformHardwareList() {
		return platformHardwareList;
	}

	public void addPlatformHardware(String platformHardware) {
		platformHardwareList.add(platformHardware);
	}

	public void setPlatformHardwareList(List<String> platformHardwareList) {
		this.platformHardwareList = platformHardwareList;
	}

	public List<String> getPlatformOSList() {
		return platformOSList;
	}

	public void addPlatformOS(String platformOS) {
		platformOSList.add(platformOS);
	}

	public void setPlatformOSList(List<String> platformOSList) {
		this.platformOSList = platformOSList;
	}

	public List<String> getPriorities() {
		return priorities;
	}

	public void addPriority(String priority) {
		priorities.add(priority);
	}

	public void setPriorities(List<String> priorities) {
		this.priorities = priorities;
	}

	public List<String> getSeverities() {
		return severities;
	}

	public void addSeverity(String severity) {
		severities.add(severity);
	}

	public void setSeverities(List<String> severities) {
		this.severities = severities;
	}

	public List<String> getResolution() {
		return resolution;
	}

	public void setResolution(List<String> resolution) {
		this.resolution = resolution;
	}

}
