package listeners;

import org.elsys.FileBugChooseProduct;
import org.elsys.data.App;
import org.elsys.utilities.Utilities;

import android.content.Context;
import android.content.Intent;
import android.view.View;

/**
 * Click listener for the File bug action item
 * 
 * @extends {@link ActionItemClickListener}
 */
public class ActionFileBugClickListener extends ActionItemClickListener {

	/**
	 * Constructs new {@link ActionFileBugClickListener}
	 * 
	 * @param context the Activity Context
	 */
	public ActionFileBugClickListener(Context context) {
		super(context);
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		if ((Boolean) v.getTag()) {
			if (Utilities.isLoggedIn(context, App.get().getAccount())) {
				intent = new Intent(context, FileBugChooseProduct.class);
				context.startActivity(intent);
			}
		}
	}
}
