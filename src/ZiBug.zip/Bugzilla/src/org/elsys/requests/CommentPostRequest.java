package org.elsys.requests;

import org.elsys.R;
import org.elsys.data.App;
import org.elsys.data.Bug;
import org.elsys.data.Comment;

import android.content.Context;

public class CommentPostRequest extends BugzillaHttpPostPutRequest {

	private Bug bug;

	public CommentPostRequest(Context context, Comment comment) {
		super(context, context.getString(R.string.comment_post_message),
				context.getString(R.string.http_post), comment);

		bug = App.get().getBug();
		if (bug != null) {
			execute("bug/" + bug.getId() + "/comment");
		}
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (!error) {
			if (bug != null) {
				new BugTokenRequest(context, bug);
			}
		}
	}
}
