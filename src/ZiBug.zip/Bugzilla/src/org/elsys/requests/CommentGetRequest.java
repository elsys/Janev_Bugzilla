package org.elsys.requests;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.elsys.BugComprehensiveView;
import org.elsys.data.App;
import org.elsys.data.Bug;
import org.elsys.parser.ParseStreamJson;

import android.content.Context;
import android.widget.Toast;

public class CommentGetRequest extends BugzillaHttpGetRequest {

	private Bug bug;

	public CommentGetRequest(Context context, Bug bug) {
		super(context, null);

		this.bug = bug;

		execute("bug/" + bug.getId() + "?include_fields=comments");
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (!error) {
			App.get().getBug().setBug(bug);
			BugzillaHttpPostPutRequest.isInProgress = false;
			((BugComprehensiveView) context).notifyDataChange();
		}
	}

	@Override
	protected void processStream(org.codehaus.jackson.JsonParser jParser)
			throws IOException, JsonParseException {
		ParseStreamJson.readComments(jParser, bug);
	}

}
