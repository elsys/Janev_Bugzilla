package org.elsys.requests;

import org.codehaus.jackson.map.ser.FilterProvider;
import org.codehaus.jackson.map.ser.impl.SimpleBeanPropertyFilter;
import org.codehaus.jackson.map.ser.impl.SimpleFilterProvider;
import org.elsys.Main;
import org.elsys.R;
import org.elsys.data.Bug;

import android.content.Context;
import android.content.Intent;

/**
 * Subclass of {@link BugzillaHttpPostPutRequest}. Responsible for uploading a
 * bug to the server.
 */
public class BugPostRequest extends BugzillaHttpPostPutRequest {

	/**
	 * Constructs a new BugPostRequest
	 * 
	 * @param context
	 *            the Activity context
	 * @param bug
	 *            the bug which is to be filed
	 */
	public BugPostRequest(Context context, Bug bug) {
		super(context, context.getString(R.string.bug_post_message), context
				.getString(R.string.http_post), bug);

		FilterProvider filters = new SimpleFilterProvider().addFilter(
				"bugFilter", SimpleBeanPropertyFilter.serializeAllExcept());
		mapper.setFilters(filters);
		
		execute("bug");

	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();

		isInProgress = false;
		
		Intent intent = new Intent(context, Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		context.startActivity(intent);
	}
}
