package org.elsys.requests;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.elsys.BugzillaActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.widget.Toast;

import javax.net.ssl.HttpsURLConnection;

/**
 * Subclass of {@link BugzillaHttpRequest}. Determines the operations needed for
 * executing a HTTP GET request to the Bugzilla server
 * 
 * <li>
 * {@link #cancelDialog()} <li>
 * {@link #readJsonStream(InputStream)} <li>
 * {@link #processStream(JsonReader)}
 * 
 * @see BugzillaHttpRequest
 * @see BugzillaHttpPostPutRequest
 */
public abstract class BugzillaHttpGetRequest extends BugzillaHttpRequest {

	private static ProgressDialog dialog;

	/**
	 * Constructs new {@link BugzillaHttpGetRequest}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param showMessage
	 *            the message to be shown while executing the request. Set to
	 *            null if no message to be shown
	 */
	protected BugzillaHttpGetRequest(Context context, String showMessage) {
		super(context, showMessage);
	}

	/** Removes the current ProgressDialog */
	protected void cancelDialog() {
		if (dialog != null) {
			dialog.cancel();
		}
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();

		if (showMessage != null) {
			if (dialog != null && !dialog.getContext().equals(context)) {
				dialog.cancel();
				dialog = null;
			}
			if (dialog == null)
				dialog = new ProgressDialog(context);
			dialog.setTitle(showMessage + "...");
			dialog.setCancelable(true);
			dialog.show();
			dialog.setOnCancelListener(new OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cancel(true);
				}
			});
		}
	}

	@Override
	protected Void doInBackground(String... params) {
		try {
			openConnection(params[0]);
			https.setRequestProperty("Accept", "application/json");
			if (https.getResponseCode() == HttpURLConnection.HTTP_OK) {
				readJsonStream(https.getInputStream());
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (https != null) {
				https.disconnect();
			}
		}
		return null;
	}

	@Override
	protected void onCancelled() {
		super.onCancelled();
		cancelDialog();
		((BugzillaActivity) context).returnToPreviousActivity();
	}

	/**
	 * Creates a {@link JsonParser} from the {@link InputStream} of the
	 * {@link HttpsURLConnection} and tries to read the input data
	 * 
	 * @param in
	 *            the {@link InputStream}
	 * @throws IOException
	 */
	private void readJsonStream(InputStream in) throws IOException, JsonParseException {
		JsonFactory jFactory = new JsonFactory();
		JsonParser jParser = null;
		try {
			jParser = jFactory.createJsonParser(in);
			if (jParser != null) {
				processStream(jParser);
			}
		} finally {
			if (jParser != null) {
				jParser.close();
			}
		}
		error = false;
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		cancelDialog();
		if (error) {
			Toast.makeText(context, "Unable to contact server",
					Toast.LENGTH_SHORT).show();
			((BugzillaActivity) context).returnToPreviousActivity();
			BugzillaHttpPostPutRequest.isInProgress = false;
		}
	}

	/**
	 * Processes the response from the server
	 * 
	 * @param jParser
	 *            {@link JsonParser} from the {@link InputStream}
	 * 
	 * @throws IOException
	 */
	protected abstract void processStream(JsonParser jParser)
			throws IOException, JsonParseException;

}