package adapters;

/**
 * Defines operations for inflating TextView views <li>
 * {@link #inflateTextViews()}
 */
public interface TextViewAdapter {

	/** Inflates the corresponding TextView views */
	public void inflateTextViews();
}
