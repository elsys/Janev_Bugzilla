package org.elsys.data;

import org.elsys.utilities.AccountConfigurationPersistor;
import org.elsys.utilities.AccountPersistor;

import android.app.Application;

public class App extends Application {

	private static App sInstance;

	private Account account;
	
	private Bug bug;
	
	@Override
	public void onCreate() {
		super.onCreate();
		sInstance = this;
		account = AccountPersistor.getCurrentPersistedAccount(this);
		if (account != null) {
			account.setAccountConfiguration(AccountConfigurationPersistor.getConfiguration(this, account.getAccountId()));
		}
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Bug getBug() {
		return bug;
	}
	
	public void setBug(Bug bug) {
		this.bug = bug;
	}
	
	public static App get() {
		return sInstance;
	}
	
}
