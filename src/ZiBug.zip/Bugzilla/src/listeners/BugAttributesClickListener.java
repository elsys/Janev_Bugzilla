package listeners;

import org.elsys.data.Bug;
import org.elsys.data.Product;
import org.elsys.requests.BugPutRequest;
import org.elsys.requests.BugzillaHttpPostPutRequest;

import adapters.AttributesBaseAdapter.ViewHolderAttributes;
import adapters.LayoutBaseAdapter;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

public class BugAttributesClickListener extends BugBaseClickListener {

	private ViewHolderAttributes viewHolder;

	public BugAttributesClickListener(LayoutBaseAdapter adapter) {
		super(adapter);
		this.viewHolder = (ViewHolderAttributes) adapter.getViewHolder();
	}

	public void onClick(View v) {
			Product selectedProduct = (Product) ((Spinner) viewHolder.getProduct())
					.getSelectedItem();
			String selectedComponent = (String) ((Spinner) viewHolder
					.getComponent()).getSelectedItem();

			Product product = new Product(selectedProduct.getProductName());
			product.setComponent(selectedComponent);
			product.setTargetMilestone(bug.getProduct().getTargetMilestone());
			product.setVersion(((Spinner) viewHolder.getVersion())
					.getSelectedItem().toString());

			Bug dupBug = new Bug(bug);

			dupBug.setProduct(product);
			dupBug.setOperatingSystem((String) ((Spinner) viewHolder.getOs())
					.getSelectedItem());
			dupBug.setPlatform((String) ((Spinner) viewHolder.getHardware())
					.getSelectedItem());
			dupBug.setSeverity((String) ((Spinner) viewHolder.getSeverity())
					.getSelectedItem());
			dupBug.setPriority((String) ((Spinner) viewHolder.getPriority())
					.getSelectedItem());

			new BugPutRequest(context, dupBug);
	}

}
