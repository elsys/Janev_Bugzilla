package adapters;

import listeners.BugAttributesClickListener;

import org.elsys.R;
import org.elsys.data.Bug;
import org.elsys.data.Product;

import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;

/**
 * Responsible for representing the Bug attributes in the case the Bug creator
 * is the account user. In that case the class parameter should be Spinner.
 * 
 * @param <T>
 *            Spinner
 * @implements {@link SpinnerAdapter}
 * @extends {@link AttributesBaseAdapter}
 * @see AttributesBaseAdapter
 * @see SpinnerAdapter
 * @see BugAttributesAdapter
 */
public class BugAttributesAdapterCreator<T> extends AttributesBaseAdapter<T>
		implements SpinnerAdapter {

	protected Button saveChangesButton;

	/**
	 * Constructs new {@link BugAttributesAdapterCreator}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the Bug which attributs will be shown
	 */
	public BugAttributesAdapterCreator(Context context, Bug bug) {
		super(context, bug, R.layout.bug_attributes);
	}

	@Override
	public View inflate() {
		super.inflate();
		inflateSpinners();
		setSelections();
		setListeners();

		return v;
	}

	@Override
	protected void setViews() {
		super.setViews();
		saveChangesButton = (Button) v
				.findViewById(R.id.bug_attr_save_changes_button);
	}

	public void inflateSpinners() {
		if (accountConfiguration != null) {
			SpinnerInflator.inflateSpinner((Spinner) viewHolder.product,
					accountConfiguration.getProducts(), context);

			SpinnerInflator.inflateSpinner((Spinner) viewHolder.hardware,
					accountConfiguration.getPlatformHardwareList(), context);
			SpinnerInflator.inflateSpinner((Spinner) viewHolder.os,
					accountConfiguration.getPlatformOSList(), context);
			SpinnerInflator.inflateSpinner((Spinner) viewHolder.priority,
					accountConfiguration.getPriorities(), context);
			SpinnerInflator.inflateSpinner((Spinner) viewHolder.severity,
					accountConfiguration.getSeverities(), context);
		}
	}

	public void setSelections() {
		SpinnerInflator.setSelection((Spinner) viewHolder.product, bug
				.getProduct().getProductName());
		SpinnerInflator.setSelection((Spinner) viewHolder.hardware,
				bug.getPlatform());
		SpinnerInflator.setSelection((Spinner) viewHolder.os,
				bug.getOperatingSystem());
		SpinnerInflator.setSelection((Spinner) viewHolder.priority,
				bug.getPriority());
		SpinnerInflator.setSelection((Spinner) viewHolder.severity,
				bug.getSeverity());

		targetMilestone.setText(bug.getProduct().getTargetMilestone());
	}

	public void setListeners() {
		saveChangesButton.setOnClickListener(new BugAttributesClickListener(
				this));

		((Spinner) viewHolder.product)
				.setOnItemSelectedListener(new OnItemSelectedListener() {
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						System.out.println(((Product) arg0
								.getItemAtPosition(arg2)).getProductName());

						System.out.println(((Product) arg0
								.getItemAtPosition(arg2)).getComponents());

						SpinnerInflator.inflateSpinner(
								(Spinner) viewHolder.component, ((Product) arg0
										.getItemAtPosition(arg2))
										.getComponents(), context);
						SpinnerInflator.setSelection(
								(Spinner) viewHolder.component, bug
										.getProduct().getComponent());
						SpinnerInflator.inflateSpinner(
								(Spinner) viewHolder.version,
								((Product) arg0.getItemAtPosition(arg2))
										.getVersions(), context);
						SpinnerInflator.setSelection(
								(Spinner) viewHolder.version, bug.getProduct()
										.getVersion());
					}

					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
					}
				});
	}
}
