package listeners;

import org.elsys.BugList;
import org.elsys.R;
import org.elsys.data.App;
import org.elsys.utilities.Utilities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;

/**
 * Click listener for the My bugs action item
 * 
 * <li>
 * {@link #showAlertDialog(CharSequence[])}
 * 
 * @extends {@link ActionItemClickListener}
 */
public class ActionMyBugsClickListener extends ActionItemClickListener {

	/**
	 * Constructs new {@link ActionMyBugsClickListener}
	 * 
	 * @param context
	 *            the Activity Context
	 */
	public ActionMyBugsClickListener(Context context) {
		super(context);
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		if ((Boolean) v.getTag()) {
			if (Utilities.isLoggedIn(context, App.get().getAccount())) {
				final CharSequence[] items = context.getResources()
						.getStringArray(R.array.my_bugs_queries_choices);
				showAlertDialog(items);
			}
		}

	}

	/**
	 * Shows an AlertDialog containing the list of available "My bugs" choices
	 * 
	 * @param context
	 *            the Activity Context
	 * @param items
	 *            the items in the AlertDialog
	 */
	private void showAlertDialog(final CharSequence[] items) {

		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle("Choose query:");
		builder.setItems(items, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int item) {
				intent = new Intent(context, BugList.class);
				intent.putExtra("type", items[item]);
				context.startActivity(intent);
			}
		});
		AlertDialog alert = builder.create();
		alert.show();
	}
}
