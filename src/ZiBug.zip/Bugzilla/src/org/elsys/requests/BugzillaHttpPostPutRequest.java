package org.elsys.requests;

import java.io.OutputStream;
import java.net.HttpURLConnection;

import javax.net.ssl.HttpsURLConnection;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.elsys.utilities.Utilities;

import android.content.Context;
import android.widget.Toast;

/**
 * Subclass of {@link BugzillaHttpRequest}. Determines the operations needed for
 * executing a HTTP POST or HTTP PUT request to the Bugzilla server
 * 
 * @see BugzillaHttpRequest
 * @see BugzillaHttpGetRequest
 */
public class BugzillaHttpPostPutRequest extends BugzillaHttpRequest {

	protected ObjectMapper mapper;

	protected int sendTimeOut;

	private String partOfUrl, dataToSend;

	private String typeOfRequest;

	private Object objectToSend;

	public static boolean isInProgress = false;

	/**
	 * Constructs new {@link BugzillaHttpPostPutRequest}.
	 * 
	 * @param context
	 *            the Activity Context
	 * @param showMessage
	 *            the message to be shown when uploading is started and after it
	 *            is finished
	 * @param typeOfRequest
	 *            the type of request to be executed. There are two
	 *            possibilities for the type - POST or PUT
	 */
	public BugzillaHttpPostPutRequest(Context context, String showMessage,
			String typeOfRequest, Object objectToSend) {
		super(context, showMessage);
		this.sendTimeOut = 2;
		this.typeOfRequest = typeOfRequest;
		this.objectToSend = objectToSend;
		mapper = new ObjectMapper();
	}

	/**
	 * Constructs new {@link BugzillaHttpPostPutRequest}.
	 * 
	 * @param context
	 *            the Activity Context
	 * @param showMessage
	 *            the message to be shown when uploading is started and after it
	 *            is finished
	 * @param typeOfRequest
	 *            the type of request to be executed. There are two
	 *            possibilities for the type - POST or PUT
	 * @param sendTimeOut
	 *            an int showing how many tries to connect to the server the
	 *            connection has
	 */
	public BugzillaHttpPostPutRequest(Context context, String showMessage,
			String typeOfRequest, int sendTimeOut, String dataToSend) {
		super(context, showMessage);
		this.sendTimeOut = sendTimeOut;
		this.typeOfRequest = typeOfRequest;
		this.dataToSend = dataToSend;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		if (isInProgress) {
			cancel(true);
		} else {
			isInProgress = true;
			if (Utilities.isOnline(context)) {
				Toast.makeText(context, showMessage + " uploading ",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	@Override
	protected Void doInBackground(String... params) {
		OutputStream output = null;

		partOfUrl = params[0];

		try {
			if (dataToSend == null) {
				dataToSend = mapper.writeValueAsString(objectToSend);
			}

			System.out.println("DATA: " + dataToSend);

			openConnection(partOfUrl);

			https.setDoOutput(true);
			https.setFixedLengthStreamingMode(dataToSend.length());

			https.setRequestMethod(typeOfRequest);
			https.setRequestProperty("Content-Type", "application/json");

			output = https.getOutputStream();
			output.write(dataToSend.getBytes());
			output.flush();
			output.close();

			int status = ((HttpsURLConnection) https).getResponseCode();

			if (status == HttpURLConnection.HTTP_CREATED
					|| status == HttpURLConnection.HTTP_ACCEPTED) {
				error = false;
			}
		} catch (JsonGenerationException jGE) {
			showEndOfRequestMessage();
		} catch (JsonMappingException jME) {
			showEndOfRequestMessage();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (https != null) {
				https.disconnect();
			}
		}

		return null;
	}

	@Override
	protected void onCancelled() {
		super.onCancelled();
		if (isInProgress) {
			Toast.makeText(context, "Please wait. An action is in progress",
					Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (error && sendTimeOut != 0) {
			isInProgress = false;
			sendTimeOut--;
			new BugzillaHttpPostPutRequest(context, showMessage, typeOfRequest,
					sendTimeOut, dataToSend).execute(partOfUrl);
		} else {
			showEndOfRequestMessage();
		}
	}

	protected void showEndOfRequestMessage() {
		String toastMessage;

		if (!error) {
			toastMessage = showMessage + " uploaded";
		} else {
			isInProgress = false;
			toastMessage = showMessage + " failed to upload";
		}
		Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show();
	}
}
