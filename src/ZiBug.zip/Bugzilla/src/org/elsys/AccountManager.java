package org.elsys;

import java.util.ArrayList;
import java.util.List;

import listeners.AccountManagerListItemClick;

import net.londatiga.android.ActionItem;
import net.londatiga.android.QuickAction;

import org.elsys.data.Account;
import org.elsys.data.App;
import org.elsys.dialogs.LoginDialog;
import org.elsys.utilities.AccountPersistor;

import adapters.AccountManagerAccountsAdapter;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class AccountManager extends BugzillaActivity {

	private static final int DELETE_ACC_DIALOG = 2;

	private Dialog dialog;

	private ListView list;

	SharedPreferences.Editor editor;

	private List<Account> accountList = new ArrayList<Account>();

	private TextView numberOfAccounts;

	private static final int ID_EDIT = 1;
	private static final int ID_DELETE = 2;

	private Account accountToEdit;
	private Account currentAccount;
	
	private Context context;

	@Override
	public void returnToPreviousActivity() {
		App.get().setAccount(currentAccount);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.account_manager);

		currentAccount = App.get().getAccount();
		
		context = this;

		list = (ListView) findViewById(R.id.accounts_list);
		list.setCacheColorHint(Color.argb(0, 0, 0, 0));
		numberOfAccounts = (TextView) findViewById(R.id.numberOfAccounts);

		loadList();

		list.setOnItemClickListener(new AccountManagerListItemClick(this));

		ActionItem editItem = new ActionItem(ID_EDIT, "Edit", getResources()
				.getDrawable(net.londatiga.android.R.drawable.ic_add));
		ActionItem deleteItem = new ActionItem(ID_DELETE, "Delete",
				getResources().getDrawable(
						net.londatiga.android.R.drawable.ic_up));

		final QuickAction mQuickAction = new QuickAction(this);

		mQuickAction.addActionItem(editItem);
		mQuickAction.addActionItem(deleteItem);

		mQuickAction
				.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() {
					public void onItemClick(QuickAction quickAction, int pos,
							int actionId) {
						if (actionId == ID_DELETE) {
							showDialog(DELETE_ACC_DIALOG);
						} else {
							if (accountToEdit != null) {
								LoginDialog loginDialog = new LoginDialog(
										context, accountToEdit);
								loginDialog.show();
							} else {
								Toast.makeText(context,
										"Problem editing account.",
										Toast.LENGTH_SHORT).show();
							}
						}
					}
				});

		list.setOnItemLongClickListener(new OnItemLongClickListener() {

			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				accountToEdit = (Account) arg0.getItemAtPosition(arg2);
				mQuickAction.show(arg1);
				return false;
			}
		});

	}

	public void onAddAccountButton(View v) {
		LoginDialog loginDialog = new LoginDialog(context);
		loginDialog.show();
	}

	protected Dialog onCreateDialog(int id) {

		switch (id) {
		case DELETE_ACC_DIALOG: {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("Are you sure you want to delete this account?")
					.setCancelable(true)
					.setPositiveButton("Yes",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									if (accountToEdit != null) {
										AccountPersistor.deleteAccount(context,
												accountToEdit.getAccountId());
									} else {
										Toast.makeText(context,
												"Problem deleting account.",
												Toast.LENGTH_SHORT).show();
									}
								}
							})
					.setNegativeButton("No",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									dialog.cancel();
								}
							});
			AlertDialog alert = builder.create();
			dialog = alert;
			break;
		}
		}

		return dialog;
	}

	public void loadList() {
		accountList.clear();
		accountList = AccountPersistor.getPersistedAccounts(context);

		list.setAdapter(new AccountManagerAccountsAdapter(this, accountList));

		numberOfAccounts.setText(accountList == null ? "0" : String
				.valueOf(accountList.size()));
	}

	public void onActionBarHomeClick(View v) {
		Intent intent = new Intent(this, Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putParcelable("account", App.get().getAccount());
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		LoginDialog dialog = new LoginDialog(this,
				(Account) savedInstanceState.getParcelable("account"));
		dialog.show();
	}
}
