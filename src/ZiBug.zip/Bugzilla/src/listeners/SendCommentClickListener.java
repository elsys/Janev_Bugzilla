package listeners;

import org.elsys.data.Comment;
import org.elsys.requests.CommentPostRequest;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

public class SendCommentClickListener implements OnClickListener {

	private EditText text;
	private Context context;

	public SendCommentClickListener(EditText text, Context context) {
		this.text = text;
		this.context = context;
	}

	public void onClick(View v) {
		String commentText = text.getText().toString();
		if (!"".equals(commentText)) {
			new CommentPostRequest(context, new Comment(commentText));
			text.setText("");
			InputMethodManager imm = (InputMethodManager) context
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(text.getWindowToken(), 0);
		} else {
			Toast.makeText(context, "Comment must not be empty",
					Toast.LENGTH_SHORT).show();
		}
	}

}
