package org.elsys;

import org.elsys.data.App;
import org.elsys.data.Bug;
import org.elsys.dialogs.SearchDialog;
import org.elsys.requests.BugDetailsRequest;
import org.elsys.utilities.Utilities;

import com.viewpagerindicator.TitlePageIndicator;

import adapters.ViewPagerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

/**
 * The Activity which takes care of presenting the Bug details
 * 
 */
public class BugComprehensiveView extends BugzillaActivity {

	private ViewPager pager;
	private TitlePageIndicator indicator;
	private TextView summary, bugIdTextView;

	private ViewPagerAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bug_comprehensive_view);

		pager = (ViewPager) findViewById(R.id.viewpager);
		indicator = (TitlePageIndicator) findViewById(R.id.indicator);
		summary = (TextView) findViewById(R.id.comprehensive_summary);
		bugIdTextView = (TextView) findViewById(R.id.comprehensive_bug_id);

		new BugDetailsRequest(this);

	}

	/**
	 * A callback method to be invoked when HTTP request
	 * {@link BugDetailsRequest} is over and should process its response
	 */
	public void processResponse() {

		Bug bug = App.get().getBug();
		if (bug != null) {
			adapter = new ViewPagerAdapter(this, bug);
			pager.setAdapter(adapter);
			indicator.setViewPager(pager);
			summary.setText(bug.getSummary());
			bugIdTextView.setText("#" + bug.getId());
		}

	}

	/**
	 * Notifies the {@link ViewPagerAdapter} that some of the Bug data has
	 * changed and the adapter should refresh itself
	 */
	public void notifyDataChange() {
		adapter.notifyDataSetChanged();
	}
	
	/**
	 * Notifies the {@link ViewPagerAdapter} that the BugPutRequest has 
	 * failed and the adapter should return the previous bug settings
	 */
	public void notifyError() {
		adapter.notifyError();
	}

	/**
	 * Called when the home button is clicked. The Main Activity is shown
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarHomeClick(View v) {
		Intent intent = new Intent(this, org.elsys.Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}

	/**
	 * Called when action bar "Accounts" button is clicked.
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarAccountsClick(View v) {
		Intent intent = new Intent(this, AccountManager.class);
		startActivity(intent);
	}

	/**
	 * Called when action bar "Search" button has been clicked.
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarSearchClick(View v) {
		if (Utilities.isAccountSelected(this)) {
			new SearchDialog(this).show();
		}
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putParcelable("bug", App.get().getBug());
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);

		App.get().setBug((Bug) savedInstanceState.getParcelable("bug"));
		processResponse();
	}
}