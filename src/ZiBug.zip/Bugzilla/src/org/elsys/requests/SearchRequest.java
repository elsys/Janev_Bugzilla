package org.elsys.requests;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonParseException;
import org.elsys.BugList;
import org.elsys.R;
import org.elsys.data.AccountConfiguration;
import org.elsys.data.Bug;
import org.elsys.parser.ParseStreamJson;

import android.content.Context;
import android.os.Bundle;

/**
 * Subclass of {@link BugzillaHttpGetRequest}. Executes a HTTP GET request to
 * the Bugzilla server requesting a list of bugs
 * 
 * <li>
 * {@link #computeRequest(Bundle) }
 * 
 * @see BugzillaHttpGetRequest
 */
public class SearchRequest extends BugzillaHttpGetRequest {

	private Context context;

	private List<Bug> bugs;

	/**
	 * Constructs new {@link SearchRequest}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param request
	 *            the request
	 */
	public SearchRequest(Context context, Bundle extras) {
		super(context, context.getString(R.string.search_message));
		this.context = context;
		bugs = new ArrayList<Bug>();
		execute(computeRequest(extras));
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (!error) {
			((BugList) context).processData(bugs);
		}
	}

	@Override
	protected void processStream(org.codehaus.jackson.JsonParser jParser)
			throws IOException, JsonParseException {
		ParseStreamJson.readBugs(jParser, bugs);
		
	}
	
	/**
	 * Computes the search request from the given Bundle extras
	 * 
	 * @param extras
	 *            the Bundle that holds the data needed for the request
	 * @return the request
	 */
	private String computeRequest(Bundle extras) {
		AccountConfiguration accountConfiguration = account
				.getAccountConfiguration();
		StringBuilder request = new StringBuilder("bug?");
		if (extras.size() > 1) {

			List<org.elsys.data.Status> statuses = accountConfiguration
					.getStatuses(extras.getString("type"));

			if (statuses.size() != 0) {
				for (int i = 0; i < statuses.size(); i++) {
					request.append("status=");
					request.append(statuses.get(i).getStatus() + "&");
				}
			}
			request.append("product="
					+ URLEncoder.encode(extras.getString("product")));
			request.append("&content="
					+ URLEncoder.encode(extras.getString("content")));
		} else {
			if (context.getString(R.string.my_open_bugs).equals(
					extras.getString("type"))) {
				List<org.elsys.data.Status> statuses = accountConfiguration
						.getStatuses(context.getString(R.string.status_open));
				for (int i = 0; i < statuses.size(); i++) {
					request.append("status=");
					request.append(statuses.get(i).getStatus() + "&");
				}
				request.append("email1="
						+ URLEncoder.encode(account.getUserEmail()) + "&");
				request.append("email1_type=equals&");
				request.append("email1_assigned_to=1&");
				request.append("email1_creator=1");
			} else {
				request.append("creator="
						+ URLEncoder.encode(account.getUserEmail()));
			}
		}
		return request.toString();
	}
}
