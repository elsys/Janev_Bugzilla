package listeners;

import org.elsys.data.Bug;
import org.elsys.data.Status;
import org.elsys.requests.BugPutRequest;

import adapters.LayoutBaseAdapter;
import adapters.SpinnerAdapter;
import adapters.StatusesBaseAdapter.ViewHolderStatus;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Spinner;

public class BugStatusClickListener extends BugBaseClickListener {

	private ViewHolderStatus viewHolder;
	
	public BugStatusClickListener(LayoutBaseAdapter adapter) {
		super(adapter);
		viewHolder = (ViewHolderStatus) adapter.getViewHolder();
	}
	
	public void onClick(View v) {
		Status selectedStatus = (Status) ((Spinner)viewHolder.getStatus()).getSelectedItem();
		String selectedResolution = (String) ((Spinner)viewHolder.getResolution()).getSelectedItem();
		String duplicateOf = viewHolder.getDuplicate().getText().toString();
		
		if(selectedResolution == null || Status.STATUS_TYPE.OPEN.equals(selectedStatus.getStatusType())) {
			selectedResolution = "";
		}
		
		if("".equals(duplicateOf) || !"DUPLICATE".equals(selectedResolution)) {
			duplicateOf = null;
		}

		Bug dupBug = new Bug(bug); 
		
		dupBug.setDuplicate(duplicateOf);
		dupBug.setStatus(new Status(selectedStatus.getStatus(), selectedResolution));
		
		adapter.setBug(dupBug);
		((SpinnerAdapter) adapter).inflateSpinners();
		((SpinnerAdapter) adapter).setSelections();
		
		InputMethodManager imm = (InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(viewHolder.getDuplicate().getWindowToken(), 0);
		
		new BugPutRequest(context, dupBug);
	}

}
