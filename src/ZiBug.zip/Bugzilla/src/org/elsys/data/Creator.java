package org.elsys.data;

import android.os.Parcel;
import android.os.Parcelable;

public class Creator implements Parcelable{
	
	private String name;
	private String realName;
	
	public Creator(String name, String realName) {
		this.name = name;
		this.realName = realName;
	}
	
	private Creator(Parcel in) {
		name = in.readString();
		realName = in.readString();
	}
	
	public String getName() {
		return name;
	}
	
	public String getRealName() {
		return realName;
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(name);
		dest.writeString(realName);
	}
	
	public static final Parcelable.Creator<org.elsys.data.Creator> CREATOR = new Creator<org.elsys.data.Creator>() {
		
		public org.elsys.data.Creator[] newArray(int size) {
			return null;
		}
		
		public org.elsys.data.Creator createFromParcel(Parcel source) {
			return new org.elsys.data.Creator(source);
		}
	};
	
}
