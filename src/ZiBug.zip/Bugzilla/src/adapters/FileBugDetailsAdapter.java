package adapters;

import listeners.FileBugClickListener;

import org.elsys.R;
import org.elsys.data.Product;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Responsible for taking and representing all the details information for
 * creating a new bug
 * 
 * @extends {@link LayoutBaseAdapter}
 * @implements {@link SpinnerAdapter}, {@link TextViewAdapter}
 * @see LayoutBaseAdapter LayoutBaseAdapter
 * @see SpinnerAdapter SpinnerAdapter
 * @see TextViewAdapter TextViewAdapter
 */
public class FileBugDetailsAdapter extends LayoutBaseAdapter implements
		SpinnerAdapter, TextViewAdapter {

	private ViewHolderFileBug viewHolder;

	/**
	 * Inner class responsible for holding the specifics Views associated with
	 * that adapter
	 */
	public class ViewHolderFileBug extends BaseViewHolder {
		protected Spinner hardware, os, severity, version;
		protected EditText summary, description;

		/**
		 * @return hardware Spinner
		 */
		public Spinner getVersion() {
			return version;
		}

		/**
		 * @return hardware Spinner
		 */
		public Spinner getHardware() {
			return hardware;
		}

		/**
		 * @return os Spinner
		 */
		public Spinner getOs() {
			return os;
		}

		/**
		 * @return severity Spinner
		 */
		public Spinner getSeverity() {
			return severity;
		}

		/**
		 * @return summary EditText
		 */
		public EditText getSummary() {
			return summary;
		}

		/**
		 * @return description EditText
		 */
		public EditText getDescription() {
			return description;
		}
	}

	private Product product;
	private TextView reporter, productTextView, component;
	private Button submit;

	/**
	 * Constructs a new FileBugAdapter
	 * 
	 * @param context
	 *            the Activity context
	 * @param resId
	 *            the resource file for the layout
	 * @param product
	 *            the chosen Product
	 */
	public FileBugDetailsAdapter(Context context, int resId, Product product) {
		super(context, resId);
		this.product = product;
		this.viewHolder = new ViewHolderFileBug();
	}

	@Override
	public View inflate() {
		super.inflate();
		inflateTextViews();
		inflateSpinners();
		setListeners();
		return v;
	}

	public void inflateTextViews() {
		reporter.setText(account.getUserEmail());
		productTextView.setText(product.getProductName());
		component.setText(product.getComponent());
	}

	@Override
	protected void setViews() {
		reporter = (TextView) v.findViewById(R.id.file_bug_reporter);

		productTextView = (TextView) v.findViewById(R.id.file_bug_product);
		component = (TextView) v.findViewById(R.id.file_bug_component);

		viewHolder.version = (Spinner) v.findViewById(R.id.file_bug_version);
		viewHolder.hardware = (Spinner) v.findViewById(R.id.file_bug_hardware);
		viewHolder.os = (Spinner) v.findViewById(R.id.file_bug_os);
		viewHolder.severity = (Spinner) v.findViewById(R.id.file_bug_severity);

		viewHolder.summary = (EditText) v.findViewById(R.id.file_bug_summary);
		viewHolder.description = (EditText) v
				.findViewById(R.id.file_bug_description);

		submit = (Button) v.findViewById(R.id.file_bug_submit);
	}

	@Override
	public BaseViewHolder getViewHolder() {
		return viewHolder;
	}

	public void inflateSpinners() {
		SpinnerInflator.inflateSpinner(viewHolder.hardware,
				accountConfiguration.getPlatformHardwareList(), context);
		SpinnerInflator.inflateSpinner(viewHolder.os,
				accountConfiguration.getPlatformOSList(), context);
		SpinnerInflator.inflateSpinner(viewHolder.severity,
				accountConfiguration.getSeverities(), context);
		SpinnerInflator.inflateSpinner(viewHolder.version,
				product.getVersions(), context);
	}

	public void setSelections() {
	}

	public void setListeners() {
		submit.setOnClickListener(new FileBugClickListener(this, product));
	}
}
