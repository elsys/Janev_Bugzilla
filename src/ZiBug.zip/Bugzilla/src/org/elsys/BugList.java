package org.elsys;

import java.util.List;

import listeners.BugListItemClickListener;

import org.elsys.data.App;
import org.elsys.data.Bug;
import org.elsys.dialogs.SearchDialog;
import org.elsys.requests.SearchRequest;

import adapters.BugListAdapter;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

/** The Activity which takes care of showing the list of bugs */
public class BugList extends BugzillaActivity {

	private ListView bugList;

	private Intent intent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bug_list_layout);

		bugList = (ListView) findViewById(R.id.bug_list_view);
		bugList.setCacheColorHint(Color.argb(0, 0, 0, 0));

		account = App.get().getAccount();

		Bundle extras = getIntent().getExtras();

		if (extras != null && account != null) {
			new SearchRequest(this, extras);
		}
	}

	/**
	 * A callback method to be invoked when HTTP request {@link SearchRequest} is over and should
	 * process its response of List of Bug-s
	 * 
	 * @param bugs
	 *            the response to be processed
	 */
	public void processData(List<Bug> bugs) {
		if(bugs.size() != 0) {
			bugList.setAdapter(new BugListAdapter(this, bugs));
			bugList.setOnItemClickListener(new BugListItemClickListener(this));
		} else {
			setContentView(R.layout.bug_list_empty);
			
		}
	}

	/**
	 * Called when action bar "Search" button has been clicked. 
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarSearchClick(View v) {
		new SearchDialog(this).show();
	}

	/**
	 * Called when action bar "Accounts" button is clicked. 
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarAccountClick(View v) {
		intent = new Intent(this, org.elsys.AccountManager.class);
		startActivity(intent);
	}

	/**
	 * Called when the home button is clicked. The Main Activity is shown
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarHomeClick(View v) {
		Intent intent = new Intent(this, org.elsys.Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}
}