package org.elsys.data;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import org.elsys.utilities.Utilities;

import android.os.Parcel;
import android.os.Parcelable;

@JsonSerialize(include = Inclusion.NON_NULL)
public class Comment implements Parcelable {

	private String date;
	private String text;
	private org.elsys.data.Creator creator;

	public Comment(String text) {
		this.text = text;
	}

	public Comment(String date, String text, org.elsys.data.Creator creator) {
		this.date = Utilities.decodeDate(date);
		this.text = text;
		this.creator = creator;
	}

	public Comment(Parcel in) {
		date = in.readString();
		text = in.readString();
		creator = in.readParcelable(org.elsys.data.Creator.class
				.getClassLoader());
	}

	public Comment() {
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = Utilities.decodeDate(date);
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public org.elsys.data.Creator getCreator() {
		return creator;
	}

	public void setCreator(org.elsys.data.Creator creator) {
		this.creator = creator;
	}
	
	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(date);
		dest.writeString(text);
		dest.writeParcelable(creator, 0);
	}

	public static final Parcelable.Creator<Comment> CREATOR = new Parcelable.Creator<Comment>() {
		public Comment createFromParcel(Parcel in) {
			return new Comment(in);
		}

		public Comment[] newArray(int size) {
			return null;
		}
	};
}
