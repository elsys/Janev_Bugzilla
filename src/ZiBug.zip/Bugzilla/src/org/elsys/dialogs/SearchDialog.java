package org.elsys.dialogs;

import java.util.List;

import org.elsys.R;
import org.elsys.data.App;
import org.elsys.data.Product;

import adapters.SpinnerInflator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class SearchDialog extends Dialog implements OnClickListener {

	private Context context;
	private Button searchButton;
	private Spinner statusSpinner, productSpinner;
	private EditText keyWord;

	public SearchDialog(Context context) {
		super(context);
		this.context = context;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		getWindow();
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.search_dialog);
		setCancelable(true);
		setDialogViews();
		setSpinnerSettings();

		searchButton.setOnClickListener(this);

	}

	public void onClick(View v) {
		
		Intent intent = new Intent(context, org.elsys.BugList.class);
		if(!"".equals(keyWord.getText().toString())) {
			intent.putExtra("type", (String)statusSpinner.getSelectedItem());
			intent.putExtra("product", (String) productSpinner.getSelectedItem()
					.toString());
			intent.putExtra("content", keyWord.getText().toString());
			context.startActivity(intent);
			dismiss();
		} else {
			Toast.makeText(context, "Keyword field must be filled in", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void setDialogViews() {
		statusSpinner = (Spinner) findViewById(R.id.search_dialog_spinner_status);
		productSpinner = (Spinner) findViewById(R.id.search_dialog_spinner_product);
		keyWord = (EditText) findViewById(R.id.search_dialog_keyword);
		searchButton = (Button) findViewById(R.id.search_dialog_button);
	}

	private void setSpinnerSettings() {
		ArrayAdapter<CharSequence> statusAdapter = ArrayAdapter
				.createFromResource(context, R.array.bug_status_list,
						android.R.layout.simple_spinner_item);
		statusAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		statusSpinner.setAdapter(statusAdapter);
		statusSpinner.setSelection(0);

		if (App.get().getAccount() != null) {
			List<Product> products = App.get().getAccount()
					.getAccountConfiguration().getProducts();

			SpinnerInflator.inflateSpinner(productSpinner, products, context);
			
//			ArrayAdapter<Product> productAdapter = new ArrayAdapter<Product>(
//					context, android.R.layout.simple_spinner_item, products);
//			productAdapter
//					.setDropDownViewResource(R.layout.spinner_dropdown_item);
//			productSpinner.setAdapter(productAdapter);
		}

	}

}
