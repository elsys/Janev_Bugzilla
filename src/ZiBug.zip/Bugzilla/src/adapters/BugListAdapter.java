package adapters;

import java.util.List;

import org.elsys.R;
import org.elsys.data.Bug;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Inflates the corresponding ListView with Bug objects
 * 
 * @extends {@link BaseAdapter}
 * @see BaseAdapter
 */
public class BugListAdapter extends BaseAdapter {

	private List<Bug> bugs;
	private Context context;

	public class ViewHolder {
		TextView bugId;
		TextView bugSev;
		TextView bugStat;
		TextView bugSummary;
	}

	/**
	 * Constructs new {@link BugListAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bugs
	 *            the List of Bug objects
	 */
	public BugListAdapter(Context context, List<Bug> bugs) {
		this.context = context;
		this.bugs = bugs;
	}

	public int getCount() {
		return bugs.size();
	}

	public Object getItem(int position) {
		return bugs.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null || convertView.getTag() == null) {
			convertView = View.inflate(context, R.layout.bug_holder, null);
			holder = new ViewHolder();
			holder.bugId = (TextView) convertView.findViewById(R.id.bug_id);
			holder.bugSev = (TextView) convertView
					.findViewById(R.id.bug_severity);
			holder.bugStat = (TextView) convertView
					.findViewById(R.id.bug_status);
			holder.bugSummary = (TextView) convertView
					.findViewById(R.id.bug_summary);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		Bug bug = (Bug) getItem(position);
		holder.bugId.setText("#" + String.valueOf(bug.getId()));
		holder.bugSev.setText(bug.getSeverity());
		holder.bugStat.setText(bug.getStatus().getStatus());
		holder.bugSummary.setText(bug.getSummary());

		convertView.requestLayout();
		return convertView;
	}
}