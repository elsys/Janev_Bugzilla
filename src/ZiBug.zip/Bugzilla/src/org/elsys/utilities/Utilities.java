package org.elsys.utilities;


import org.elsys.data.Account;
import org.elsys.data.App;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

/**
 * Utility class
 * 
 * <li>
 * {@link #isOnline(Context)} <li> {@link #decodeDate(String)} <li>
 * {@link #isAccountSelected(Context)} <li>
 * {@link #isLoggedIn(Context, Account)}
 */
public class Utilities {

	/**
	 * Parses the data from the server by the specified format
	 * 
	 * @param date
	 *            the date format from the server
	 * @return the parsed date
	 */
	public static String decodeDate(String date) {
		date = date.replace('T', ' ');
		date = date.replace('Z', ' ');
		return date;
	}


	/**
	 * Checks if a network connection is available
	 * 
	 * @param context
	 *            the Activity Context
	 * @return true if a network connection is available, false otherwise
	 */
	public static boolean isOnline(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnected()) {
			return true;
		}
		return false;
	}

	/**
	 * Checks if an account is selected and there is a configuration for that
	 * account
	 * 
	 * @return true if account and account configuration are not null, false
	 *         otherwise
	 */
	public static boolean isAccountSelected(Context context) {
		if (App.get().getAccount() != null
				&& App.get().getAccount().getAccountConfiguration() != null) {
			return true;
		} else {
			Toast.makeText(context, "No account selected", Toast.LENGTH_SHORT)
					.show();
			return false;
		}
	}

	/**
	 * Checks if the user is logged in for the current account
	 * 
	 * @return true if there is a user for that account, false otherwise
	 */
	public static boolean isLoggedIn(Context context, Account account) {
		if (account.isLoggedIn()) {
			return true;
		} else {
			Toast.makeText(context, "Not logged in", Toast.LENGTH_SHORT).show();
			return false;
		}
	}
}
