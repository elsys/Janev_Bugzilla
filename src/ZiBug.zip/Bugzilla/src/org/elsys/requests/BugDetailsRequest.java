package org.elsys.requests;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.elsys.BugComprehensiveView;
import org.elsys.R;
import org.elsys.data.App;
import org.elsys.data.Bug;
import org.elsys.parser.ParseStreamJson;

import android.content.Context;

public class BugDetailsRequest extends BugzillaHttpGetRequest {

	private Bug bug;

	public BugDetailsRequest(Context context) {
		super(context, context.getString(R.string.fetch_message));

		bug = App.get().getBug();
		if (bug != null) {
			if (bug.getCreator() == null) {
				execute("bug/" + bug.getId()
						+ "?include_fields=_default,comments,attachments.data");
			} else {
				((BugComprehensiveView) context).processResponse();
			}
		}
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (!error) {
			((BugComprehensiveView) context).processResponse();
		}

	}

	@Override
	protected void processStream(org.codehaus.jackson.JsonParser jParser)
			throws IOException, JsonParseException {
		ParseStreamJson.readBugDetails(jParser, bug);
	}
}
