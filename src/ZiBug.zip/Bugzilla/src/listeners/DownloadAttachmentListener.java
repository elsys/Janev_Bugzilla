package listeners;

import org.elsys.data.Attachment;
import org.elsys.utilities.DownloadFile;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;

public class DownloadAttachmentListener implements OnItemLongClickListener {

	private Context context;

	public DownloadAttachmentListener(Context context) {
		this.context = context;
	}

	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {

		final Attachment attachment = (Attachment) arg0.getItemAtPosition(arg2);
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Do you want to download attachment?")
				.setCancelable(true)
				.setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								new DownloadFile(context, attachment
										.getFileName(), attachment.getData(),
										attachment.getContentType())
										.downloadFile();
							}
						})
				.setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});
		builder.create().show();
		return true;
	}

}
