package org.elsys.requests;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.elsys.data.Bug;
import org.elsys.parser.ParseStreamJson;

import android.content.Context;

public class BugTokenRequest extends BugzillaHttpGetRequest {

	private Bug bug;

	public BugTokenRequest(Context context, Bug bug) {
		super(context, null);

		this.bug = bug;

		execute("bug/" + bug.getId() + "?include_fields=update_token");
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);

		if (!error) {
			new CommentGetRequest(context, bug);
		}
	}

	@Override
	protected void processStream(org.codehaus.jackson.JsonParser jParser)
			throws IOException, JsonParseException {
		bug.setUpdateToken(ParseStreamJson.readUpdateToken(jParser));
	}

}
