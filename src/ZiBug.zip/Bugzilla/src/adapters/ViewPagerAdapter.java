package adapters;

import listeners.DownloadAttachmentListener;
import listeners.SendCommentClickListener;

import org.elsys.R;
import org.elsys.data.Account;
import org.elsys.data.App;
import org.elsys.data.Bug;

import android.content.Context;
import android.graphics.Color;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.viewpagerindicator.TitleProvider;

/**
 * Responsible for inflating the {@link ViewPager} <li>
 * {@link #inflateAttributesView() } <li>
 * {@link #inflateStatusView() } <li>
 * {@link #inflateCommentsView() } <li>
 * {@link #notifyCommentChange() } <li>
 * {@link #notifyAttributesChange()} <li>
 * {@link #notifyStatusChange() }
 */
public class ViewPagerAdapter extends PagerAdapter implements TitleProvider {
	private static String[] titles = new String[] { "Comments", "Attributes",
			"Status", "Attachments" };

	private int count = titles.length;

	private final Context context;

	private Bug bug;
	private Account account;

	private CommentAdapter commentAdapter;
	AttributesBaseAdapter<?> adapterAtrributes = null;
	StatusesBaseAdapter<?> adapterStatuses = null;

	private boolean isCreator = false;

	/**
	 * Constructs new {@link ViewPagerAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the Bug which data will be shown
	 */
	public ViewPagerAdapter(Context context, Bug bug) {
		this.context = context;
		this.bug = bug;

		account = App.get().getAccount();

		isCreator = account.isLoggedIn() ? account.getUserEmail().equals(
				bug.getCreator().getName()) ? true : false : false;
	}

	/** Inflates the attributes section with the Bug attributes data */
	private View inflateAttributesView() {
		if (!isCreator) {
			adapterAtrributes = new BugAttributesAdapter<TextView>(context, bug);
		} else {
			adapterAtrributes = new BugAttributesAdapterCreator<Spinner>(
					context, bug);
		}
		return adapterAtrributes.inflate();
	}

	/** Inflates the status section with the Bug status data */
	private View inflateStatusView() {
		if (!isCreator) {
			adapterStatuses = new BugStatusAdapter<TextView>(context, bug);
		} else {
			adapterStatuses = new BugStatusAdapterCreator<Spinner>(context, bug);
		}
		return adapterStatuses.inflate();
	}

	/** Inflates the comment section with the Bug comments */
	private View inflateCommentsView() {
		View view = View.inflate(context, R.layout.comment_section, null);
		ListView list = (ListView) view
				.findViewById(R.id.comments_section_list);
		commentAdapter = new CommentAdapter(context, bug.getComments());
		list.setAdapter(commentAdapter);
		int visibility;
		if (account != null && account.isLoggedIn()) {
			visibility = View.VISIBLE;
		} else {
			visibility = View.GONE;
		}
		view.findViewById(R.id.comment_section_send).setVisibility(visibility);
		return view;
	}

	/**
	 * Called when there is a change in the Bug comments and the comments
	 * section should be refreshed
	 */
	private void notifyCommentChange() {
		if (bug != null) {
			commentAdapter.setComments(bug.getComments());
			commentAdapter.notifyDataSetChanged();
		}
	}

	/**
	 * Called when there is a change in the Bug status and the status section
	 * should be refreshed
	 */
	private void notifyStatusChange() {
		if (bug != null && adapterStatuses != null) {
			adapterStatuses.setBug(bug);
			((SpinnerAdapter) adapterStatuses).inflateSpinners();
			((SpinnerAdapter) adapterStatuses).setSelections();
		}
	}

	/**
	 * Called when there is a change in the Bug attributes and the attributes
	 * section should be refreshed
	 */
	private void notifyAttributesChange() {
		if (bug != null) {
			adapterAtrributes.setBug(bug);
			((SpinnerAdapter) adapterAtrributes).setSelections();
		}
	}

	public String getTitle(int position) {
		return titles[position];
	}

	@Override
	public int getCount() {
		return count;
	}

	/**
	 * Creates a new TextView
	 * 
	 * @param response
	 *            the message of the TextView
	 * @return the created TextView
	 */
	private TextView getTextView(String response) {
		TextView textView = new TextView(context);
		textView.setGravity(Gravity.CENTER);
		textView.setText(response);
		return textView;
	}

	@Override
	public Object instantiateItem(View pager, int position) {
		View v = null;

		if (position == 0) {
			if (bug.getComments() != null) {
				v = inflateCommentsView();
				EditText text = (EditText) v
						.findViewById(R.id.send_comment_text);
				((Button) v.findViewById(R.id.send_comment_button))
						.setOnClickListener(new SendCommentClickListener(text,
								context));
			}
		} else if (position == 1) {
			v = inflateAttributesView();
		} else if (position == 2) {
			v = inflateStatusView();
		} else {
			if (bug.getAttachments() != null
					&& bug.getAttachments().size() != 0) {
				v = new ListView(context);
				DownloadAttachmentListener listener = new DownloadAttachmentListener(
						context);

				((ListView) v).setOnItemLongClickListener(listener);
				((ListView) v).setCacheColorHint(Color.argb(0, 0, 0, 0));
				((ListView) v).setAdapter(new AttachmentAdapter(context, bug
						.getAttachments()));
			} else {
				v = getTextView("No attachments");
			}
		}

		((ViewPager) pager).addView(v);
		return v;
	}

	@Override
	public void destroyItem(View pager, int position, Object view) {
		((ViewPager) pager).removeView((View) view);
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {
		return view.equals(object);
	}

	@Override
	public void finishUpdate(View view) {
	}

	@Override
	public void restoreState(Parcelable p, ClassLoader c) {
	}

	@Override
	public Parcelable saveState() {
		return null;
	}

	@Override
	public void startUpdate(View view) {
	}

	@Override
	public void notifyDataSetChanged() {
		super.notifyDataSetChanged();

		bug = App.get().getBug();
		notifyCommentChange();
		
	}
	
	public void notifyError() {
		bug = App.get().getBug();
		notifyAttributesChange();
		notifyStatusChange();
	}
}