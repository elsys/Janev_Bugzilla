package listeners;

import org.elsys.FileBugDetails;
import org.elsys.data.Product;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;

public class FileBugProductClickListener implements OnChildClickListener {

	private Context context;
	private ExpandableListAdapter adapter;
	
	public FileBugProductClickListener(Context context, ExpandableListAdapter adapter) {
		this.context = context;
		this.adapter = adapter;
	}
	
	public boolean onChildClick(ExpandableListView parent, View v,
			int groupPosition, int childPosition, long id) {
		Intent intent = new Intent(context, FileBugDetails.class);

		Product product = (Product) adapter.getGroup(groupPosition);
		product.setComponent((String) adapter.getChild(groupPosition,
				childPosition));

		intent.putExtra("product", product.getProductName());

		context.startActivity(intent);

		return true;
	}

}
