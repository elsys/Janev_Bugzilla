package org.elsys.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonToken;
import org.elsys.data.AccountConfiguration;
import org.elsys.data.Attachment;
import org.elsys.data.Bug;
import org.elsys.data.Comment;
import org.elsys.data.Creator;
import org.elsys.data.Product;
import org.elsys.data.Status;
import org.elsys.data.Status.STATUS_TYPE;

/**
 * Describes the operations for parsing the input data
 * 
 * <li>
 * {@link #readBugs(JsonParser, List) }
 */
public class ParseStreamJson {

	public static AccountConfiguration readAccountConfiguration(
			JsonParser jParser) throws JsonParseException, IOException {
		AccountConfiguration accountConfiguration = new AccountConfiguration();
		jParser.nextToken();
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			String fieldName = jParser.getCurrentName();
			if ("product".equals(fieldName)) {
				while (jParser.nextToken() != JsonToken.END_OBJECT) {
					accountConfiguration.addProduct(readProduct(jParser));
				}
			} else if ("field".equals(fieldName)) {
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_OBJECT) {
					if ("priority".equals(jParser.getText())) {
						accountConfiguration.setPriorities(readValues(jParser));
					} else if ("resolution".equals(jParser.getText())) {
						accountConfiguration.setResolution(readValues(jParser));
					} else if ("op_sys".equals(jParser.getText())) {
						accountConfiguration
								.setPlatformOSList(readValues(jParser));
					} else if ("platform".equals(jParser.getText())) {
						accountConfiguration
								.setPlatformHardwareList(readValues(jParser));
					} else if ("severity".equals(jParser.getText())) {
						accountConfiguration.setSeverities(readValues(jParser));
					} else if ("status".equals(jParser.getText())) {
						readStatuses(jParser, accountConfiguration);
					} else if (jParser.getCurrentToken() == JsonToken.START_OBJECT) {
						jParser.skipChildren();
					}
				}
			} else {
				if (jParser.getCurrentToken() == JsonToken.START_OBJECT) {
					jParser.skipChildren();
				}
			}
		}

		return accountConfiguration;
	}

	private static void readStatuses(JsonParser jParser,
			AccountConfiguration accountConfiguration)
			throws JsonParseException, IOException {
		jParser.nextToken();
		List<Status> statuses = null;
		Status status = null;
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			if ("closed".equals(jParser.getText())) {
				statuses = new ArrayList<Status>();
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_ARRAY) {
					status = new Status(jParser.getText(), STATUS_TYPE.CLOSED);
					statuses.add(status);
					accountConfiguration.addStatus(status);
				}
				accountConfiguration.addStatusToMap("Closed", statuses);
			} else if ("open".equals(jParser.getText())) {
				statuses = new ArrayList<Status>();
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_ARRAY) {
					status = new Status(jParser.getText(), STATUS_TYPE.OPEN);
					statuses.add(status);
					accountConfiguration.addStatus(status);
				}
				accountConfiguration.addStatusToMap("Open", statuses);
			} else if ("transitions".equals(jParser.getText())) {
				List<Status> initialValues = new ArrayList<Status>();
				List<Status> transitions = null;
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_OBJECT) {
					String statusName = jParser.getText();
					if ("{Start}".equals(statusName)) {
						jParser.nextToken();
						while (jParser.nextToken() != JsonToken.END_ARRAY) {
							initialValues.add(new Status(jParser.getText()));
						}
					} else {
						transitions = new ArrayList<Status>();
						jParser.nextToken();
						while (jParser.nextToken() != JsonToken.END_ARRAY) {
							transitions.add(new Status(jParser.getText()));
						}
						accountConfiguration.setTransitionsForStatus(
								statusName, transitions);
					}
				}
				accountConfiguration.removeInitialValues(initialValues);
			}
		}
	}

	private static List<String> readValues(JsonParser jParser)
			throws JsonParseException, IOException {
		List<String> values = new ArrayList<String>();
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			if ("values".equals(jParser.getText())) {
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_ARRAY) {
					String text = jParser.getText();
					if (!"".equals(text)) {
						values.add(jParser.getText());
					}
				}
			}
		}
		return values;
	}

	private static Product readProduct(JsonParser jParser)
			throws JsonParseException, IOException {
		Product product = new Product();
		List<String> components = new ArrayList<String>();
		jParser.nextToken();
		String productName = jParser.getCurrentName();
		product.setProductName(productName);
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			String name = jParser.getCurrentName();
			if ("component".equals(name)) {
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_OBJECT) {
					String compName = jParser.getCurrentName();
					if (jParser.getCurrentToken() == JsonToken.FIELD_NAME) {
						components.add(compName);
					} else if (jParser.getCurrentToken() == JsonToken.START_OBJECT) {
						jParser.skipChildren();
					}
				}
				product.setComponents(components);
			} else if ("version".equals(name)) {
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_ARRAY) {
					product.addVersion(jParser.getText());
				}
			} else if ("target_milestone".equals(name)) {
				jParser.nextToken();
				while (jParser.nextToken() != JsonToken.END_ARRAY) {
				}
			}
		}
		return product;
	}

	public static void readBugs(JsonParser jParser, List<Bug> bugs)
			throws JsonParseException, IOException {
		jParser.nextToken();
		jParser.nextToken();

		Bug bug = null;
		Status status = null;

		while (jParser.nextToken() != JsonToken.END_ARRAY) {
			bug = new Bug();
			status = new Status();
			if (jParser.nextToken() == JsonToken.END_ARRAY) {
				break;
			}
			while (jParser.nextToken() != JsonToken.END_OBJECT) {
				String fieldName = jParser.getCurrentName();
				if ("assigned_to".equals(fieldName)) {
					jParser.skipChildren();
				} else if ("qa_contact".equals(fieldName)) {
					jParser.skipChildren();
				} else if ("id".equals(fieldName)) { //
					bug.setId(jParser.nextIntValue(-1));
				} else if ("summary".equals(fieldName)) { //
					bug.setSummary(jParser.nextTextValue());
				} else if ("status".equals(fieldName)) { //
					status.setStatus(jParser.nextTextValue());
				} else if ("severity".equals(fieldName)) { //
					bug.setSeverity(jParser.nextTextValue());
				} else if ("creator".equals(fieldName)) {
					jParser.skipChildren();
				} else if ("resolution".equals(fieldName)) { //
					status.setResolution(jParser.nextTextValue());
				}
			}
			bug.setStatus(status);
			bugs.add(bug);
		}
	}

	public static void readBugDetails(JsonParser jParser, Bug bug)
			throws JsonParseException, IOException {
		Product product = new Product();
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			String fieldName = jParser.getCurrentName();
			if ("priority".equals(fieldName)) {
				bug.setPriority(jParser.nextTextValue());
			} else if ("creator".equals(fieldName)) {
				bug.setCreator(readCreator(jParser));
			} else if ("comments".equals(fieldName)) {
				readComments(jParser, bug);
			} else if ("assigned_to".equals(fieldName)) {
				while (jParser.nextToken() != JsonToken.END_OBJECT) {
					if ("name".equals(jParser.getCurrentName())) {
						bug.setAssignee(jParser.nextTextValue());
					}
				}
			} else if ("qa_contact".equals(fieldName)) {
				jParser.skipChildren();
			} else if ("platform".equals(fieldName)) {
				bug.setPlatform(jParser.nextTextValue());
			} else if ("version".equals(fieldName)) {
				product.setVersion(jParser.nextTextValue());
			} else if ("component".equals(fieldName)) {
				product.setComponent(jParser.nextTextValue());
			} else if ("target_milestone".equals(fieldName)) {
				product.setTargetMilestone(jParser.nextTextValue());
			} else if ("product".equals(fieldName)) {
				product.setProductName(jParser.nextTextValue());
			} else if ("op_sys".equals(fieldName)) {
				bug.setOperatingSystem(jParser.nextTextValue());
			} else if ("update_token".equals(fieldName)) {
				bug.setUpdateToken(jParser.nextTextValue());
			} else if ("dupe_of".equals(fieldName)) {
				bug.setDuplicate(String.valueOf(jParser.nextIntValue(0)));
			} else if ("attachments".equals(fieldName)) {
				readAttachments(jParser, bug);
			} else if ("cc".equals(fieldName)) {
				jParser.skipChildren();
			}
		}
		bug.setProduct(product);
	}

	private static void readAttachments(JsonParser jParser, Bug bug)
			throws JsonParseException, IOException {
		Attachment attachment = null;
		while (jParser.nextToken() != JsonToken.END_ARRAY) {
			attachment = new Attachment();
			while (jParser.nextToken() != JsonToken.END_OBJECT) {
				String fieldName = jParser.getCurrentName();
				if ("data".equals(fieldName)) {
					attachment.setData(jParser.nextTextValue());
				} else if ("description".equals(fieldName)) {
					attachment.setDescription(jParser.nextTextValue());
				} else if ("content_type".equals(fieldName)) {
					attachment.setContentType(jParser.nextTextValue());
				} else if ("attacher".equals(fieldName)) {
					attachment.setCreator(readCreator(jParser));
				} else if ("file_name".equals(fieldName)) {
					attachment.setFileName(jParser.nextTextValue());
				} else if ("creation_time".equals(fieldName)) {
					attachment.setCreationTime(jParser.nextTextValue());
				}
			}
			bug.addAttachment(attachment);
		}
	}

	public static void readComments(JsonParser jParser, Bug bug)
			throws JsonParseException, IOException {
		bug.setComments(null);
		Comment comment = null;
		if (jParser.getCurrentToken() == JsonToken.START_OBJECT) {
			jParser.nextToken();
		}

		while (jParser.nextToken() != JsonToken.END_ARRAY) {
			comment = new Comment();
			while (jParser.nextToken() != JsonToken.END_OBJECT) {
				String fieldName = jParser.getCurrentName();
				if ("creator".equals(fieldName)) {
					comment.setCreator(readCreator(jParser));
				} else if ("text".equals(fieldName)) {
					comment.setText(jParser.nextTextValue());
				} else if ("creation_time".equals(fieldName)) {
					comment.setDate(jParser.nextTextValue());
				}
			}
			bug.addComment(comment);
		}
	}

	private static Creator readCreator(JsonParser jParser)
			throws JsonParseException, IOException {
		String name = null;
		String realName = null;
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			String fieldName = jParser.getCurrentName();
			if ("name".equals(fieldName)) {
				name = jParser.nextTextValue();
			} else if ("real_name".equals(fieldName)) {
				realName = jParser.nextTextValue();
			}
		}
		return new Creator(name, realName);
	}

	public static String readUpdateToken(JsonParser jParser)
			throws JsonParseException, IOException {
		while (jParser.nextToken() != JsonToken.END_OBJECT) {
			String fieldName = jParser.getCurrentName();
			if ("update_token".equals(fieldName)) {
				return jParser.nextTextValue();
			}
		}
		return null;
	}
}
