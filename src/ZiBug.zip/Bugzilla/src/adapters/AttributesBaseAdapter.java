package adapters;

import org.elsys.R;
import org.elsys.data.Bug;

import android.content.Context;
import android.widget.TextView;

/**
 * Base adapter for representing Bug attributes information. The class is
 * parameterized in order its subclasses to determine if the adapter should show
 * Spinner views (if the Bug is created by the account user) or TextView views
 * (if the Bug is not created by the account user).
 * 
 * @extends {@link LayoutBaseAdapter}
 * @param <T>
 *            could be Spinner or TextView depending of its subclass
 * 
 * @see LayoutBaseAdapter
 * @see BugAttributesAdapterCreator
 * @see BugAttributesAdapter
 */
public class AttributesBaseAdapter<T> extends LayoutBaseAdapter {

	protected ViewHolderAttributes viewHolder;

	/**
	 * ViewHolder for holding the views for the attributes of the Bug.
	 * @extends {@link BaseViewHolder}
	 */
	public class ViewHolderAttributes extends BaseViewHolder {
		protected T product, component, hardware, os, priority, severity, version;

		public T getVersion() {
			return version;
		}
		
		public T getProduct() {
			return product;
		}

		public T getComponent() {
			return component;
		}

		public T getHardware() {
			return hardware;
		}

		public T getOs() {
			return os;
		}

		public T getPriority() {
			return priority;
		}

		public T getSeverity() {
			return severity;
		}
	}

	protected TextView targetMilestone;

	/**
	 * Constructs new {@link AttributesBaseAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the Bug which attributes should be shown
	 * @param resId
	 *            the resource id of the layout
	 */
	public AttributesBaseAdapter(Context context, Bug bug, int resId) {
		super(context, bug, resId);
		viewHolder = new ViewHolderAttributes();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected void setViews() {
		viewHolder.product = (T) v.findViewById(R.id.bug_attr_spinner_product);
		viewHolder.component = (T) v
				.findViewById(R.id.bug_attr_spinner_component);
		viewHolder.hardware = (T) v
				.findViewById(R.id.bug_attr_platform_hardware);
		viewHolder.os = (T) v.findViewById(R.id.bug_attr_platform_os);
		viewHolder.priority = (T) v
				.findViewById(R.id.bug_attr_importance_priority);
		viewHolder.severity = (T) v
				.findViewById(R.id.bug_attr_importance_severity);

		viewHolder.version = (T) v.findViewById(R.id.bug_attr_version);
		targetMilestone = (TextView) v
				.findViewById(R.id.bug_attr_target_milestone);
	}

	@Override
	public BaseViewHolder getViewHolder() {
		return viewHolder;
	}
}
