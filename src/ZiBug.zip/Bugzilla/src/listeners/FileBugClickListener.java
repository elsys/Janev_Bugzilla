package listeners;

import org.elsys.data.Bug;
import org.elsys.data.Comment;
import org.elsys.data.Product;
import org.elsys.requests.BugPostRequest;

import adapters.FileBugDetailsAdapter.ViewHolderFileBug;
import adapters.LayoutBaseAdapter;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

/**
 * Listener to be invoked when then "Submit bug" button is clicked and a bug is
 * to be filed
 */
public class FileBugClickListener extends BugBaseClickListener {

	private ViewHolderFileBug viewHolder;
	private Product product;

	/**
	 * Constructs a new FileBugClickListener
	 * 
	 * @param adapter
	 *            the adapter associated with that listener
	 * @param product
	 *            the product for the bug
	 */
	public FileBugClickListener(LayoutBaseAdapter adapter, Product product) {
		super(adapter);
		this.viewHolder = (ViewHolderFileBug) adapter.getViewHolder();
		this.product = product;
	}

	public void onClick(View v) {
		if ("".equals(viewHolder.getSummary().getText().toString())) {
			Toast.makeText(context, "Fill summary field", Toast.LENGTH_SHORT)
					.show();
		} else {
			Product bugProduct = new Product(product.getProductName());
			bugProduct.setComponent(product.getComponent());
			bugProduct.setVersion(viewHolder.getVersion().getSelectedItem().toString());
			Bug bug = new Bug(viewHolder.getSummary().getText().toString(),
					bugProduct);
			bug.addComment(new Comment(viewHolder.getDescription().getText()
					.toString()));
			bug.setOperatingSystem(viewHolder.getOs().getSelectedItem()
					.toString());
			bug.setPlatform(viewHolder.getHardware().getSelectedItem()
					.toString());
			bug.setSeverity(viewHolder.getSeverity().getSelectedItem()
					.toString());

			InputMethodManager imm = (InputMethodManager) context
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(viewHolder.getSummary()
					.getWindowToken(), 0);
			imm.hideSoftInputFromWindow(viewHolder.getDescription()
					.getWindowToken(), 0);
			
			new BugPostRequest(context, bug);
		}
	}

}
