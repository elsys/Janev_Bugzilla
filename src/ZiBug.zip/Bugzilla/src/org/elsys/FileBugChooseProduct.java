package org.elsys;


import listeners.FileBugProductClickListener;

import org.elsys.data.Account;
import org.elsys.data.App;
import org.elsys.dialogs.SearchDialog;

import adapters.ProductExpandableListAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

/**
 * This activity takes the responsibility of showing the available products and
 * components of the account and processing the user choice
 * 
 */
public class FileBugChooseProduct extends Activity {

	private ExpandableListView listView;
	private ExpandableListAdapter adapter;
	private Account account;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.file_bug_products);

		account = App.get().getAccount();
		if (account != null) {

			listView = (ExpandableListView) findViewById(R.id.expandable_list_products);

			adapter = new ProductExpandableListAdapter(account
					.getAccountConfiguration().getProducts(), this);

			listView.setAdapter(adapter);

			listView.setOnChildClickListener(new FileBugProductClickListener(
					this, adapter));
		}

	}

	/**
	 * Called when action bar "Search" button has been clicked.
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarSearchClick(View v) {
		new SearchDialog(this).show();
	}

	/**
	 * Called when action bar "Accounts" button is clicked.
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarAccountClick(View v) {
		Intent intent = new Intent(this, org.elsys.AccountManager.class);
		startActivity(intent);
	}

	/**
	 * Called when the home button is clicked. The Main Activity is shown
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarHomeClick(View v) {
		Intent intent = new Intent(this, org.elsys.Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}
}
