package org.elsys.data;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonUnwrapped;
import org.codehaus.jackson.map.annotate.JsonFilter;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import android.os.Parcel;
import android.os.Parcelable;

@JsonFilter("bugFilter")
@JsonSerialize(include = Inclusion.NON_NULL)
public class Bug implements Parcelable {

	@JsonIgnore
	private int id;
	private String severity;
	private String priority;
	private String operatingSystem;
	@JsonIgnore
	private String assignee;
	private String summary;
	private String platform;
	private String updateToken;
	private String duplicate;
	
	@JsonUnwrapped
	private Product product;
	
	@JsonUnwrapped
	private Status status;
	
	@JsonIgnore
	private org.elsys.data.Creator creator;

	private List<Comment> comments;
	@JsonIgnore
	private List<Attachment> attachments;

	public Bug(int id, String summary) {
		this.id = id;
		this.summary = summary;
	}

	public Bug(Bug bug) {
		lazyCopy(bug);
	}
	
	public void setBug(Bug bug) {
		lazyCopy(bug);
	}
	
	public Bug() {
		
	}
	
	public Bug(String summary, Product product) {
		this.summary = summary;
		this.product = product;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	@JsonProperty("op_sys")
	public String getOperatingSystem() {
		return operatingSystem;
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public org.elsys.data.Creator getCreator() {
		return creator;
	}

	public void setCreator(org.elsys.data.Creator creator) {
		this.creator = creator;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Product getProduct() {
		return product;
	}
	
	public void setProduct(Product product) {
		this.product = product;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public void addComment(Comment comment) {
		if (comments == null) {
			comments = new ArrayList<Comment>();
		}
		comments.add(comment);
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public List<Attachment> getAttachments() {
		return attachments;
	}

	public void addAttachment(Attachment attachment) {
		if (attachments == null) {
			attachments = new ArrayList<Attachment>();
		}
		attachments.add(attachment);
	}

	@JsonProperty("update_token")
	public String getUpdateToken() {
		return updateToken;
	}
	
	public void setUpdateToken(String updateToken) {
		this.updateToken = updateToken;
	}
	
	@JsonProperty("dupe_of")
	public String getDuplicate() {
		return duplicate;
	}
	
	public void setDuplicate(String duplicate) {
		this.duplicate = duplicate;
	}
	
	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(severity);
		dest.writeString(priority);
		dest.writeString(operatingSystem);
		dest.writeString(assignee);
		dest.writeString(summary);
		dest.writeString(platform);
		dest.writeString(updateToken);
		dest.writeString(duplicate);
		dest.writeParcelable(creator, 0);
		dest.writeList(comments);
		dest.writeList(attachments);
		dest.writeParcelable(product, 0);
		dest.writeParcelable(status, 0);
	}

	public static final Parcelable.Creator<Bug> CREATOR = new Parcelable.Creator<Bug>() {
		public Bug createFromParcel(Parcel in) {
			return new Bug(in);
		}

		public Bug[] newArray(int size) {
			return null;
		}
	};

	private Bug(Parcel in) {
		id = in.readInt();
		severity = in.readString();
		priority = in.readString();
		operatingSystem = in.readString();
		assignee = in.readString();
		summary = in.readString();
		platform = in.readString();
		updateToken = in.readString();
		duplicate = in.readString();
		creator = in.readParcelable(org.elsys.data.Creator.class.getClassLoader());
		comments = new ArrayList<Comment>();
		attachments = new ArrayList<Attachment>();
		in.readList(comments, Comment.class.getClassLoader());
		in.readList(attachments, Attachment.class.getClassLoader());
		product = in.readParcelable(Product.class.getClassLoader());
		status = in.readParcelable(Status.class.getClassLoader());
	}
	
	private void lazyCopy(Bug bug) {
		this.assignee = bug.getAssignee();
		this.attachments = bug.getAttachments();
		this.comments = bug.getComments();
		this.creator = bug.getCreator();
		this.duplicate = bug.getDuplicate();
		this.id = bug.getId();
		this.operatingSystem = bug.getOperatingSystem();
		this.platform = bug.getPlatform();
		this.priority = bug.getPriority();
		this.product = bug.getProduct();
		this.severity = bug.getSeverity();
		this.status = bug.getStatus();
		this.summary = bug.getSummary();
		this.updateToken = bug.getUpdateToken();
	}
}