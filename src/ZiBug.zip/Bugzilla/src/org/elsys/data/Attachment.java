package org.elsys.data;

import org.elsys.utilities.Utilities;

import android.os.Parcel;
import android.os.Parcelable;

public class Attachment implements Parcelable {
	private org.elsys.data.Creator creator;
	private String contentType;
	private String creationTime;
	private String data;
	private String description;
	private String fileName;

	public Attachment() {}

	public Attachment(Parcel in) {
		creator = in.readParcelable(org.elsys.data.Creator.class.getClassLoader());
		contentType = in.readString();
		creationTime = in.readString();
		data = in.readString();
		description = in.readString();
		fileName = in.readString();
	}
	
	public org.elsys.data.Creator getCreator() {
		return creator;
	}

	public void setCreator(org.elsys.data.Creator creator) {
		this.creator = creator;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = Utilities.decodeDate(creationTime);
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeParcelable(creator, 0);
		dest.writeString(contentType);
		dest.writeString(creationTime);
		dest.writeString(data);
		dest.writeString(description);
		dest.writeString(fileName);
	}

	public static final Parcelable.Creator<Attachment> CREATOR = new Parcelable.Creator<Attachment>() {
		public Attachment createFromParcel(Parcel in) {
			return new Attachment(in);
		}

		public Attachment[] newArray(int size) {
			return null;
		}
	};
}
