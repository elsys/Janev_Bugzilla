package listeners;

import org.elsys.data.App;
import org.elsys.data.Bug;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

/**
 * Click listener for the ListView showing the list of Bug objects
 * 
 * @implements {@link OnItemClickListener}
 */
public class BugListItemClickListener implements OnItemClickListener {

	private Context context;

	public BugListItemClickListener(Context context) {
		this.context = context;
	}

	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		try {
			Intent intent = new Intent(context,
					org.elsys.BugComprehensiveView.class);
			App.get().setBug((Bug) arg0.getItemAtPosition(arg2));
			context.startActivity(intent);
		} catch (IndexOutOfBoundsException ex) {
		}
	}

}
