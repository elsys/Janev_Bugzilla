package adapters;

import org.elsys.R;
import org.elsys.data.Bug;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

/**
 * Responsible for representing the Bug statuses in the case the Bug creator is
 * not the account user. In that case the class parameter should be TextView.
 * 
 * @param <T>
 *            TextView
 * @implements {@link TextViewAdapter}
 * @extends {@link StatusesBaseAdapter}
 * 
 * @see StatusesBaseAdapter
 * @see TextViewAdapter
 * @see BugStatusAdapterCreator
 */
public class BugStatusAdapter<T> extends StatusesBaseAdapter<T> implements
		TextViewAdapter {

	private TextView bugDuplicate;
	
	/**
	 * Constructs new {@link BugStatusAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the Bug which statuses will be shown
	 */
	public BugStatusAdapter(Context context, Bug bug) {
		super(context, bug, R.layout.bug_status_not_creator);
	}

	@Override
	protected void setViews() {
		super.setViews();
		bugDuplicate = (TextView) v.findViewById(R.id.bug_status_duplicate);
	}
	
	@Override
	public View inflate() {
		super.inflate();
		inflateTextViews();

		return v;
	}

	public void inflateTextViews() {
		if (accountConfiguration != null) {
			((TextView) viewHolder.status).setText(bug.getStatus().getStatus());
			((TextView) viewHolder.resolution).setText(bug.getStatus().getResolution());
			if(bug.getDuplicate() != null) {
				bugDuplicate.setText("of " + bug.getDuplicate());
			} else {
				bugDuplicate.setVisibility(View.GONE);
			}
			reporter.setText(bug.getCreator().getRealName());
			assignedTo.setText(bug.getAssignee());
		}
	}

}
