package adapters;

import java.util.List;

import org.elsys.FileBugChooseProduct;
import org.elsys.data.Product;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

public class ProductExpandableListAdapter extends BaseExpandableListAdapter {

	private Context context;
	
	private Product[] products;
	private String[][] components;

	public ProductExpandableListAdapter(List<Product> products, Context context) {
		this.products = products.toArray(new Product[products.size()]);
		components = new String[products.size()][];
		this.context = context;

		List<String> comp;
		for (int i = 0; i < components.length; i++) {
			comp = products.get(i).getComponents();
			components[i] = comp.toArray(new String[comp.size()]);
		}

	}

	public Object getChild(int groupPosition, int childPosition) {
		return components[groupPosition][childPosition];
	}

	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	public int getChildrenCount(int groupPosition) {
		return components[groupPosition].length;
	}

	/**
	 * Creates a TextView which is used as a general holder for both the groups
	 * (products) and the children (components).
	 * 
	 * @return the generated TextView
	 */
	public TextView getGenericView() {
		AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, 64);

		TextView textView = new TextView(context);
		textView.setLayoutParams(lp);
		textView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		textView.setPadding(60, 0, 0, 0);
		return textView;
	}

	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		TextView textView = getGenericView();
		textView.setText(getChild(groupPosition, childPosition).toString());
		return textView;
	}

	public Object getGroup(int groupPosition) {
		return products[groupPosition];
	}

	public int getGroupCount() {
		return products.length;
	}

	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		TextView textView = getGenericView();
		textView.setText(getGroup(groupPosition).toString());
		return textView;
	}

	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	public boolean hasStableIds() {
		return true;
	}
}
