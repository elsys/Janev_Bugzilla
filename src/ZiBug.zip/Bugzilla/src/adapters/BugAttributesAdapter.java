package adapters;

import org.elsys.R;
import org.elsys.data.Bug;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

/**
 * Responsible for representing the Bug attributes in the case the Bug creator
 * is not the account user. In that case the class parameter should be TextView.
 * 
 * @param <T>
 *            TextView
 * @implements {@link TextViewAdapter}
 * @extends {@link AttributesBaseAdapter}
 * 
 * @see AttributesBaseAdapter
 * @see TextViewAdapter
 * @see BugAttributesAdapterCreator
 */
public class BugAttributesAdapter<T> extends AttributesBaseAdapter<T> implements
		TextViewAdapter {

	/**
	 * Constructs new {@link BugAttributesAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the Bug which attributes will be shown
	 */
	public BugAttributesAdapter(Context context, Bug bug) {
		super(context, bug, R.layout.bug_attributes_not_creator);
	}

	@Override
	public View inflate() {
		super.inflate();
		inflateTextViews();

		return v;
	}

	public void inflateTextViews() {
		if (accountConfiguration != null) {
			((TextView) viewHolder.product).setText(bug.getProduct().getProductName());
			((TextView) viewHolder.component).setText(bug.getProduct().getComponent());
			((TextView) viewHolder.hardware).setText(bug.getPlatform());
			((TextView) viewHolder.os).setText(bug.getOperatingSystem());
			((TextView) viewHolder.priority).setText(bug.getPriority());
			((TextView) viewHolder.severity).setText(bug.getSeverity());
			((TextView) viewHolder.version).setText(bug.getProduct().getVersion());
			targetMilestone.setText(bug.getProduct().getTargetMilestone());
		}
	}
}
