package adapters;

import org.elsys.R;
import org.elsys.data.Bug;

import adapters.LayoutBaseAdapter.BaseViewHolder;
import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Base adapter for representing Bug statuses information. The class is
 * parameterized in order its subclasses to determine if the adapter should show
 * Spinner views (if the Bug is created by the account user) or TextView views
 * (if the Bug is not created by the account user).
 * 
 * @extends {@link LayoutBaseAdapter}
 * @param <T>
 *            could be Spinner or TextView depending of its subclass
 * 
 * @see LayoutBaseAdapter
 * @see BugStatusAdapterCreator
 * @see BugStatusAdapter
 */
public class StatusesBaseAdapter<T> extends LayoutBaseAdapter {

	protected ViewHolderStatus viewHolder;

	/**
	 * ViewHolder for holding the views for the statuses of the Bug.
	 * @extends {@link BaseViewHolder}
	 */
	public class ViewHolderStatus extends BaseViewHolder {
		protected T status, resolution;
		protected EditText duplicateEditText;

		public T getStatus() {
			return status;
		}

		public T getResolution() {
			return resolution;
		}

		public EditText getDuplicate() {
			return duplicateEditText;
		}
	}

	protected TextView assignedTo, reporter;

	/**
	 * Constructs new {@link StatusesBaseAdapter}
	 * 
	 * @param context the Activity Context
	 * @param bug the Bug which statuses will be shown
	 * @param resId the resource if of the Bug
	 */
	protected StatusesBaseAdapter(Context context, Bug bug, int resId) {
		super(context, bug, resId);
		viewHolder = new ViewHolderStatus();

	}

	@SuppressWarnings("unchecked")
	@Override
	protected void setViews() {
		viewHolder.status = (T) v.findViewById(R.id.bug_status_spinner);
		viewHolder.resolution = (T) v
				.findViewById(R.id.bug_status_spinner_resolution);

		assignedTo = (TextView) v.findViewById(R.id.bug_status_assignee);
		reporter = (TextView) v.findViewById(R.id.bug_status_reporter);
	}

	@Override
	public BaseViewHolder getViewHolder() {
		return viewHolder;
	}
}
