package org.elsys.requests;

import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.elsys.data.Account;
import org.elsys.data.App;
import org.elsys.utilities.Utilities;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

/**
 * The base class for executing HTTP requests to the Bugzilla server
 * 
 * <li>
 * {@link #trustAllHosts()} <li>
 * {@link #constructUrl(String)} <li>
 * {@link #openConnection(String[])}
 * 
 * @see BugzillaHttpGetRequest
 * @see BugzillaHttpPostPutRequest
 */
public abstract class BugzillaHttpRequest extends AsyncTask<String, Void, Void> {

	protected boolean error = true;

	private String baseUrl;
	protected Context context;
	protected Account account;

	protected String showMessage;

	protected URL url;
	protected HttpsURLConnection https;

	/**
	 * Constructs new {@link BugzillaHttpRequest}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param showMessage
	 *            the message to be shown. Set to null if no message to be shown
	 */
	protected BugzillaHttpRequest(Context context, String showMessage) {
		this.context = context;
		this.showMessage = showMessage;
		this.account = App.get().getAccount();
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();

		if (!Utilities.isOnline(context)) {
			cancel(true);
		}
	}

	/** Verifies all hosts within the SSL session */
	protected final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	};

	/** Initialize the {@link HttpsURLConnection} to trust all hosts */
	protected static void trustAllHosts() {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new java.security.cert.X509Certificate[] {};
			}

			public void checkClientTrusted(X509Certificate[] chain,
					String authType) throws CertificateException {
			}

			public void checkServerTrusted(X509Certificate[] chain,
					String authType) throws CertificateException {
			}
		} };

		try {
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection
					.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Constructs the {@link URL} for the request.
	 * 
	 * @param param
	 *            the params for the {@link URL}
	 * @return new {@link URL}
	 * @throws Exception
	 */
	protected URL constructUrl(String param) throws Exception {
		StringBuilder executeUrl = new StringBuilder();
		baseUrl = account.getAccountUrl();
		executeUrl.append(baseUrl).append(param);
		if (executeUrl.toString().indexOf('?') == -1) {
			executeUrl.append("?");
		} else {
			executeUrl.append("&");
		}
		executeUrl.append("username=").append(URLEncoder.encode(account.getUserEmail()))
				.append("&password=").append(account.getUserPassword());
		return new URL(executeUrl.toString());
	}

	/**
	 * Opens connection to the Bugzilla server
	 * 
	 * @param params
	 *            the params for the {@link URL}
	 * @throws Exception
	 */
	protected void openConnection(String param) throws Exception {
		url = constructUrl(param);
		trustAllHosts();
		System.setProperty("http.keepAlive", "false");
		https = (HttpsURLConnection) url.openConnection();
		https.setHostnameVerifier(DO_NOT_VERIFY);
	}

	@Override
	protected void onCancelled() {
		super.onCancelled();
		if (!Utilities.isOnline(context)) {
			Toast.makeText(context,
					"No internet connection right now. Please try again later",
					Toast.LENGTH_SHORT).show();
		}
	}
}
