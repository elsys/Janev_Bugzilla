package org.elsys.data;

import org.codehaus.jackson.annotate.JsonIgnore;

import android.os.Parcel;
import android.os.Parcelable;

public class Account implements Parcelable {

	private String userEmail;
	private String userPassword;
	private String accountDescription;
	private String accountUrl;
	private int accountId;

	private AccountConfiguration accountConfiguration;

	public Account() {
	}

	public Account(String userEmail, String userPassword, String accountUrl,
			String accountDescription, int accountId) {
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.accountUrl = accountUrl;
		this.accountDescription = accountDescription;
		this.accountId = accountId;
	}

	public Account(int accountId) {
		this.accountId = accountId;
	}

	public Account(Parcel in) {
		userEmail = in.readString();
		userPassword = in.readString();
		accountDescription = in.readString();
		accountUrl = in.readString();
		accountId = in.readInt();
	}

	public void setAccountConfiguration(
			AccountConfiguration accountConfiguration) {
		this.accountConfiguration = accountConfiguration;
	}

	public AccountConfiguration getAccountConfiguration() {
		return accountConfiguration;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getAccountUrl() {
		return accountUrl;
	}

	public void setAccountUrl(String accountUrl) {
		this.accountUrl = accountUrl;
	}

	public String getAccountDescription() {
		return accountDescription;
	}

	public void setAccountDescription(String accountDescription) {
		this.accountDescription = accountDescription;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
	@JsonIgnore
	public boolean isLoggedIn() {
		return "".equals(userPassword) ? false : true;
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(userEmail);
		dest.writeString(userPassword);
		dest.writeString(accountDescription);
		dest.writeString(accountUrl);
		dest.writeInt(accountId);
	}

	public static final Parcelable.Creator<Account> CREATOR = new Creator<Account>() {

		public Account[] newArray(int size) {
			return null;
		}

		public Account createFromParcel(Parcel source) {
			return new Account(source);
		}
	};
}
