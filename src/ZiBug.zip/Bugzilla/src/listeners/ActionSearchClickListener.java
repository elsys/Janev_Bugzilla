package listeners;

import org.elsys.dialogs.SearchDialog;

import android.content.Context;
import android.view.View;

/**
 * Click listener for the Search action item
 * 
 * @extends {@link ActionItemClickListener}
 */
public class ActionSearchClickListener extends ActionItemClickListener {

	/**
	 * Constructs new {@link ActionSearchClickListener}
	 * 
	 * @param context
	 *            the Activity Context
	 */
	public ActionSearchClickListener(Context context) {
		super(context);
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		if ((Boolean) v.getTag()) {
			new SearchDialog(context).show();
		}
	}
}
