package org.elsys.utilities;

import org.codehaus.jackson.map.ObjectMapper;
import org.elsys.R;
import org.elsys.data.AccountConfiguration;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class AccountConfigurationPersistor {

	private static SharedPreferences settings;
	private static SharedPreferences.Editor editor;

	private static String encryptAccountConfiguration(
			AccountConfiguration accountConfiguration) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		return SimpleCrypto.encrypt(mapper
				.writeValueAsString(accountConfiguration));
	}

	private static AccountConfiguration decryptAccountConfiguration(
			String encryptedData) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(SimpleCrypto.decrypt(encryptedData),
				AccountConfiguration.class);
	}

	public static void persistConfiguration(Context context, int id,
			AccountConfiguration configuration) {
		if (configuration != null) {
			settings = context.getSharedPreferences(context
					.getString(R.string.shared_preferences_configuration), 0);
			editor = settings.edit();
			try {
				editor.putString(String.valueOf(id),
						encryptAccountConfiguration(configuration));
				editor.commit();
			} catch (Exception e) {
				e.printStackTrace();
				Toast.makeText(context, "Unable to store configuration",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	public static AccountConfiguration getConfiguration(Context context,
			int accountId) {
		settings = context
				.getSharedPreferences(context
						.getString(R.string.shared_preferences_configuration),
						0);

		AccountConfiguration configuration = null;
		String result = settings.getString(String.valueOf(accountId), null);
		if (result != null) {
			try {
				configuration = decryptAccountConfiguration(result);
			} catch (Exception e) {
				e.printStackTrace();
				Toast.makeText(context, "Unable to retrieve configuration",
						Toast.LENGTH_SHORT).show();
			}
		}
		return configuration;
	}

	public static void removeConfiguration(Context context, int id) {
		settings = context
				.getSharedPreferences(context
						.getString(R.string.shared_preferences_configuration),
						0);
		editor = settings.edit();

		editor.remove(String.valueOf(id));
		editor.commit();
	}
}
