package adapters;

import java.util.List;

import org.elsys.R;
import org.elsys.data.Account;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class AccountManagerAccountsAdapter extends BaseAdapter {

	private Context context;
	private List<Account> accounts;
	
	public AccountManagerAccountsAdapter(Context context, List<Account> accounts) {
		this.context = context;
		this.accounts = accounts;
	}
	
	private class ViewHolder {
		TextView description;
		TextView url;
	}
	
	public int getCount() {
		return accounts.size();
	}

	public Object getItem(int position) {
		return accounts.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null || convertView.getTag() == null) {
			convertView = View.inflate(context, R.layout.accounts_list_layout, null);
			holder = new ViewHolder();

			holder.description = (TextView) convertView.findViewById(R.id.accounts_list_key);
			holder.url = (TextView) convertView.findViewById(R.id.accounts_list_value);
			
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		Account account = (Account) getItem(position);
		holder.description.setText(account.getAccountDescription());
		holder.url.setText(account.getAccountUrl());
		
		convertView.requestLayout();
		return convertView;
	}

}
