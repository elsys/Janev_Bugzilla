package org.elsys;

import org.elsys.data.App;
import org.elsys.data.Product;
import org.elsys.dialogs.SearchDialog;

import adapters.FileBugDetailsAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * This activity takes the responsibility for filling all the required by the
 * bug data
 */
public class FileBugDetails extends BugzillaActivity {

	private FileBugDetailsAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Bundle extras = getIntent().getExtras();
		if (extras != null) {

			account = App.get().getAccount();
			Product product = account.getAccountConfiguration()
					.getProductByName(extras.getString("product"));

			adapter = new FileBugDetailsAdapter(this, R.layout.file_bug,
					product);
			setContentView(adapter.inflate());
		}

	}
	
	/**
	 * Called when action bar "Search" button has been clicked. 
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarSearchClick(View v) {
		new SearchDialog(this).show();
	}

	/**
	 * Called when action bar "Accounts" button is clicked. 
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarAccountClick(View v) {
		Intent intent = new Intent(this, org.elsys.AccountManager.class);
		startActivity(intent);
	}

	/**
	 * Called when the home button is clicked. The Main Activity is shown
	 * 
	 * @param v
	 *            the View that is clicked
	 */
	public void onActionBarHomeClick(View v) {
		Intent intent = new Intent(this, org.elsys.Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}
}
