package listeners;

import org.elsys.data.Bug;

import adapters.LayoutBaseAdapter;
import android.content.Context;
import android.view.View.OnClickListener;

public abstract class BugBaseClickListener implements OnClickListener{

	protected Bug bug;
	protected LayoutBaseAdapter adapter;
	protected Context context;

	public BugBaseClickListener(LayoutBaseAdapter adapter) {
		this.bug = adapter.getBug();
		this.adapter = adapter;
		this.context = adapter.getContext();
	}
}
