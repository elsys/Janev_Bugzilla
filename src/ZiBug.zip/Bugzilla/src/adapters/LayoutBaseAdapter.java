package adapters;

import org.elsys.data.Account;
import org.elsys.data.AccountConfiguration;
import org.elsys.data.App;
import org.elsys.data.Bug;

import android.content.Context;
import android.view.View;

/**
 * Base adapter for inflating a View. <li>
 * {@link #getBug()} <li>
 * {@link #inflate()} <li>
 * {@link #getContext()} <li>
 * {@link #setViews()}
 */
public abstract class LayoutBaseAdapter {

	protected Context context;
	protected Bug bug;

	protected Account account;
	protected AccountConfiguration accountConfiguration;

	protected View v;

	/**
	 * Constructs new LayoutBaseAdapter
	 * 
	 * @param context
	 *            the Activity Context
	 * @param resId
	 *            the resource id of the inflated layout
	 */
	protected LayoutBaseAdapter(Context context, int resId) {
		this(context, null, resId);
	}

	/**
	 * Constructs new LayoutBaseAdapter
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the bug which information will be handled
	 * @param resId
	 *            the resource id of the inflated layout
	 */
	protected LayoutBaseAdapter(Context context, Bug bug, int resId) {
		this.context = context;
		this.bug = bug;

		this.account = App.get().getAccount();
		if (account != null) {
			this.accountConfiguration = account.getAccountConfiguration();
		}

		v = View.inflate(context, resId, null);

	}

	/**
	 * Return the bug corresponding to the adapter
	 * 
	 * @return bug
	 */
	public Bug getBug() {
		return bug;
	}

	/**
	 * Indicates the Bug which information will be handled
	 * 
	 * @param bug the Bug object
	 */
	public void setBug(Bug bug) {
		this.bug = bug;
	}
	
	/**
	 * Fills the layout
	 * 
	 * @return the View for the layout
	 */
	public View inflate() {
		setViews();
		return null;
	}

	/**
	 * Returns the Context corresponding to the adapter
	 * 
	 * @return context
	 */
	public Context getContext() {
		return context;
	}

	/** Base class for holding the View-s associated with the layout */
	public class BaseViewHolder {
	}

	/** Finds all the View-s associated to the layout by their id */
	protected abstract void setViews();

	/**
	 * Returns the BaseViewHolder object
	 * 
	 * @return ViewHolder object
	 */
	public abstract BaseViewHolder getViewHolder();
}
