package org.elsys.dialogs;

import java.util.Arrays;
import java.util.Set;

import org.elsys.Main;
import org.elsys.R;
import org.elsys.data.Account;
import org.elsys.data.App;
import org.elsys.requests.AccountConfigurationRequest;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginDialog extends Dialog implements OnClickListener {

	private EditText urlEditText, emailEditText, passwordEditText,
			descriptionEditText;
	private Button addAccount, cancel;

	private SharedPreferences settings;

	private Context context;

	private Account account;

	public LoginDialog(Context context) {
		super(context);
		this.context = context;
	}

	public LoginDialog(Context context, Account accountToEdit) {
		super(context);
		this.context = context;
		this.account = accountToEdit;
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case org.elsys.R.id.add_acc_button:
			addAccount();
			break;
		case org.elsys.R.id.cancel_acc_button:
			dismiss();
			break;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow();
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(org.elsys.R.layout.add_acc_dialog);
		setCancelable(true);
		setDialogViews();

		if (account != null) {
			assignAccountDataToFields();
		}

		addAccount.setOnClickListener(this);
		cancel.setOnClickListener(this);

	}

	private void assignAccountDataToFields() {
		urlEditText.setText(account.getAccountUrl());
		emailEditText.setText(account.getUserEmail());
		passwordEditText.setText(account.getUserPassword());
		descriptionEditText.setText(account.getAccountDescription());
		addAccount.setText("Edit");
	}

	private void setDialogViews() {
		urlEditText = (EditText) findViewById(org.elsys.R.id.url_add_acc_dialog);
		emailEditText = (EditText) findViewById(org.elsys.R.id.email_add_acc_dialog);
		passwordEditText = (EditText) findViewById(org.elsys.R.id.password_add_acc_dialog);
		descriptionEditText = (EditText) findViewById(org.elsys.R.id.description_add_acc_dialog);
		addAccount = (Button) findViewById(org.elsys.R.id.add_acc_button);
		cancel = (Button) findViewById(org.elsys.R.id.cancel_acc_button);
	}

	private void addAccount() {

		String url = null;
		String email = null;
		String password = null;
		String description = null;

		url = urlEditText.getText().toString().trim();
		email = emailEditText.getText().toString().trim();
		password = passwordEditText.getText().toString().trim();
		description = descriptionEditText.getText().toString().trim();

		if ("".equals(url) || "".equals(description)) {
			Toast.makeText(context,
					"You must fill the URL and Description fields.",
					Toast.LENGTH_SHORT).show();
		} else {

			if (account == null) {
				account = new Account();
				account.setAccountId(getGeneratedAccountId());
			}

			if (!(url.charAt(url.length() - 1) == '/')) {
				url = new String(url + "/");
			}

			if (!"".equals(email) && "".equals(password) || "".equals(email)
					&& !"".equals(password)) {
				Toast.makeText(
						context,
						"You must fill both the email and password fields or leave both fields blank",
						Toast.LENGTH_SHORT).show();
			} else {

				account.setUserEmail(email);
				account.setUserPassword(password);
				account.setAccountUrl(url);
				account.setAccountDescription(description);

				App.get().setAccount(account);

				new AccountConfigurationRequest(context, this);
			}

		}
	}

	private int getGeneratedAccountId() {
		int maxNumber;

		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_accounts), 0);

		Set<String> idsSet = settings.getAll().keySet();
		String[] ids = idsSet.toArray(new String[idsSet.size()]);

		Arrays.sort(ids);

		maxNumber = ids.length != 0 ? Integer.valueOf(ids[ids.length - 1]) : 0;

		return ++maxNumber;
	}

	public void proccessResponse() {
		dismiss();
		Intent intent = new Intent(context, Main.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		context.startActivity(intent);
	}

}
