package adapters;

import java.util.List;

import org.elsys.R;
import org.elsys.data.Attachment;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Responsible for representing all the attachments data.
 * 
 * @extends {@link BaseAdapter}
 * @see BaseAdapter
 * @see Attachment
 */
public class AttachmentAdapter extends BaseAdapter {
	private List<Attachment> attachments;
	private Context context;

	/**
	 * A ViewHolder for the attachment data
	 */
	public class ViewHolder {
		TextView attachmentDescription;
		TextView attachmentDate;
		TextView attachmentContentType;
		TextView attachmentAttacher;
	}

	/**
	 * Constructs a new {@link AttachmentAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param attachments
	 *            the list of Attachment objects
	 */
	public AttachmentAdapter(Context context, List<Attachment> attachments) {
		this.context = context;
		this.attachments = attachments;
	}

	public int getCount() {
		return attachments.size();
	}

	public Object getItem(int position) {
		return attachments.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null || convertView.getTag() == null) {
			convertView = View.inflate(context, R.layout.attachment_holder,
					null);
			holder = new ViewHolder();

			holder.attachmentDescription = (TextView) convertView
					.findViewById(R.id.attachment_description);
			holder.attachmentDate = (TextView) convertView
					.findViewById(R.id.attachment_date);
			holder.attachmentContentType = (TextView) convertView
					.findViewById(R.id.attachment_content_type);
			holder.attachmentAttacher = (TextView) convertView
					.findViewById(R.id.attachment_attacher);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		Attachment attachment = (Attachment) getItem(position);

		holder.attachmentDescription.setText(attachment.getDescription());
		holder.attachmentDate.setText(attachment.getCreationTime());
		holder.attachmentContentType.setText(attachment.getContentType());
		holder.attachmentAttacher.setText(attachment.getCreator().getName());

		convertView.requestLayout();
		return convertView;
	}

}
