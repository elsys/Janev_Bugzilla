package org.elsys.data;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import android.os.Parcel;
import android.os.Parcelable;

@JsonSerialize(include = Inclusion.NON_NULL)
public class Product implements Parcelable {

	private String productName;
	private String component;

	private List<String> versions;
	private List<String> components;
	private String version;
	private String targetMilestone;

	public Product(Parcel in) {
		productName = in.readString();
		component = in.readString();
		version = in.readString();
		targetMilestone = in.readString();
	}

	public Product(String productName) {
		this.productName = productName;
	}

	public Product() {

	}

	public List<String> getVersions() {
		return versions;
	}
	
	public void setVersions(List<String> versions) {
		this.versions = versions;
	}
	
	public void addVersion(String version) {
		if(versions == null) {
			versions = new ArrayList<String>();
		}
		versions.add(version);
	}
	
	@JsonProperty("product")
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	@JsonProperty("component")
	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public List<String> getComponents() {
		return components;
	}

	public void setComponents(List<String> components) {
		this.components = components;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@JsonIgnore
	public String getTargetMilestone() {
		return targetMilestone;
	}

	public void setTargetMilestone(String targetMilestone) {
		this.targetMilestone = targetMilestone;
	}

	@Override
	public String toString() {
		return productName;
	}

	@Override
	public boolean equals(Object o) {
		return productName.equals(o) ? true : false;
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(productName);
		dest.writeString(component);
		dest.writeString(version);
		dest.writeString(targetMilestone);
	}

	public static final Parcelable.Creator<Product> CREATOR = new Creator<Product>() {

		public Product[] newArray(int size) {
			return null;
		}

		public Product createFromParcel(Parcel source) {
			return new Product(source);
		}
	};
}
