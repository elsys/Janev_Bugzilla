package adapters;

import java.util.List;

import org.elsys.R;
import org.elsys.data.Comment;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Responsible for representing all the comments data
 * 
 * @extends {@link BaseAdapter}
 * @see BaseAdapter
 * @see Comment
 */
public class CommentAdapter extends BaseAdapter {

	private Context context;
	private List<Comment> comments;

	/**
	 * Constructs new {@link CommentAdapter}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param comments
	 *            the list of Comment objects
	 */
	public CommentAdapter(Context context, List<Comment> comments) {
		this.context = context;
		this.comments = comments;
	}

	public class ViewHolder {
		TextView creator;
		TextView date;
		TextView comment;
	}

	public int getCount() {
		return comments.size();
	}

	public Object getItem(int position) {
		return comments.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
		notifyDataSetChanged();
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null || convertView.getTag() == null) {
			convertView = View.inflate(context, R.layout.comments_layout, null);
			holder = new ViewHolder();

			holder.creator = (TextView) convertView
					.findViewById(R.id.comment_creator);
			holder.date = (TextView) convertView
					.findViewById(R.id.comment_date);
			holder.comment = (TextView) convertView
					.findViewById(R.id.comment_description);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		Comment comment = (Comment) getItem(position);

		holder.creator.setText(comment.getCreator().getRealName());
		holder.date.setText(comment.getDate());
		holder.comment.setText(comment.getText());

		convertView.requestLayout();
		return convertView;
	}

}
