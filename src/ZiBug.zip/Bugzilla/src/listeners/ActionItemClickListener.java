package listeners;

import org.elsys.utilities.Utilities;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;

/**
 * Basic click listener class for the dashboard action items
 *
 * @implements {@link OnClickListener} 
 */
public class ActionItemClickListener implements OnClickListener {

	protected Context context;
	protected Intent intent;
	
	/**
	 * Constructs new {@link ActionItemClickListener}
	 * 
	 * @param context the Activity Context
	 */
	public ActionItemClickListener(Context context) {
		this.context = context;
	}
	
	public void onClick(View v) {
		v.setTag(Utilities.isAccountSelected(context));
	}

}
