package org.elsys;

import org.elsys.data.Account;
import org.elsys.data.App;

import android.app.Activity;

/**
 * Subclass of Activity.
 */
public class BugzillaActivity extends Activity {
	
	protected Account account;
	
	/** Finishes the current activity and returns to the previous one*/
	public void returnToPreviousActivity() {
		finish();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		
		account = App.get().getAccount();
		
		if(account == null) {
			returnToPreviousActivity();
		}
	}
}
