package adapters;

import java.util.List;

import listeners.BugStatusClickListener;

import org.elsys.R;
import org.elsys.data.Bug;
import org.elsys.data.Status;
import org.elsys.data.Status.STATUS_TYPE;

import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

/**
 * Responsible for representing the Bug statuses in the case the Bug creator is
 * the account user. In that case the class parameter should be Spinner.
 * 
 * @param <T>
 *            Spinner
 * @implements {@link SpinnerAdapter}
 * @extends {@link StatusesBaseAdapter}
 * @see StatusesBaseAdapter
 * @see SpinnerAdapter
 * @see BugStatusAdapter
 */
public class BugStatusAdapterCreator<T> extends StatusesBaseAdapter<T>
		implements SpinnerAdapter {

	private View duplicateHolder, resolutionHolder;
	private Button saveStatusChanges;

	/**
	 * Constructs new {@link BugStatusAdapterCreator}
	 * 
	 * @param context
	 *            the Activity Context
	 * @param bug
	 *            the Bug which statuses will be shown
	 */
	public BugStatusAdapterCreator(Context context, Bug bug) {
		super(context, bug, R.layout.bug_status);
	}

	@Override
	protected void setViews() {
		super.setViews();
		viewHolder.duplicateEditText = (EditText) v
				.findViewById(R.id.bug_status_duplicate);
		duplicateHolder = v.findViewById(R.id.bug_status_duplicate_holder);
		resolutionHolder = v.findViewById(R.id.bug_status_resolution_holder);
		saveStatusChanges = (Button) v
				.findViewById(R.id.bug_status_save_changes_button);
	}

	@Override
	public View inflate() {
		super.inflate();
		inflateSpinners();
		setSelections();
		setListeners();

		return v;
	}

	public void inflateSpinners() {
		List<Status> statuses = accountConfiguration
				.getTransitionsForStatus(bug.getStatus().getStatus());
		for (Status status : statuses) {
			System.out.println(status + " " + status.getStatusType());
		}

		SpinnerInflator.inflateSpinner(((Spinner) viewHolder.status),
				accountConfiguration.getTransitionsForStatus(bug.getStatus().getStatus()),
				context);

	}

	public void setSelections() {
		SpinnerInflator.setSelection(((Spinner) viewHolder.status),
				bug.getStatus().getStatus());
		assignedTo.setText(bug.getAssignee());
		reporter.setText(bug.getCreator().getRealName());

		if (bug.getDuplicate() != null) {
			viewHolder.duplicateEditText.setText(bug.getDuplicate());
		} else {
			duplicateHolder.setVisibility(View.GONE);
		}
	}

	public void setListeners() {
		saveStatusChanges.setOnClickListener(new BugStatusClickListener(this));

		((Spinner) viewHolder.status)
				.setOnItemSelectedListener(new OnItemSelectedListener() {
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						if (STATUS_TYPE.CLOSED.equals(((Status) arg0
								.getItemAtPosition(arg2)).getStatusType())) {
							resolutionHolder.setVisibility(View.VISIBLE);
							SpinnerInflator.inflateSpinner(
									((Spinner) viewHolder.resolution),
									accountConfiguration.getResolution(),
									context);
							SpinnerInflator.setSelection(
									((Spinner) viewHolder.resolution),
									bug.getStatus().getResolution());
						} else {
							resolutionHolder.setVisibility(View.GONE);
							duplicateHolder.setVisibility(View.GONE);
						}
					}

					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
					}
				});
		((Spinner) viewHolder.resolution)
				.setOnItemSelectedListener(new OnItemSelectedListener() {

					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {

						if ("DUPLICATE".equals((String) arg0.getSelectedItem())) {
							duplicateHolder.setVisibility(View.VISIBLE);
						} else {
							duplicateHolder.setVisibility(View.GONE);
						}
					}

					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
					}
				});
	}
}
