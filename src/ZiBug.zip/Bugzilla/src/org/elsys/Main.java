package org.elsys;

import listeners.ActionAccountManagerClickListener;
import listeners.ActionFileBugClickListener;
import listeners.ActionMyBugsClickListener;
import listeners.ActionSearchClickListener;

import org.elsys.dialogs.SearchDialog;
import org.elsys.requests.AccountConfigurationRequest;
import org.elsys.utilities.Utilities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

/**
 * This is the main activity of the application which is the launching point of
 * the application as stated in the Manifest file
 * 
 * 
 */
public class Main extends BugzillaActivity {

	@Override
	public void returnToPreviousActivity() {
	}

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		setListeners();
	}

	/** Sets listeners for the dashboard buttons */
	public void setListeners() {
		
		((Button) findViewById(R.id.dashboard_profile_button))
				.setOnClickListener(new ActionMyBugsClickListener(this));
		((Button) findViewById(R.id.dashboard_search_button))
				.setOnClickListener(new ActionSearchClickListener(this));
		((Button) findViewById(R.id.dashboard_post_button))
				.setOnClickListener(new ActionFileBugClickListener(this));
		((Button) findViewById(R.id.dashboard_info_button))
				.setOnClickListener(new ActionAccountManagerClickListener(this));
	}

	/**
	 * Called when the action bar button "Accounts" has been clicked
	 * 
	 * @param v
	 *            the clicked button
	 */
	public void onActionBarAccountsClick(View v) {
		Intent intent = new Intent(this, org.elsys.AccountManager.class);
		startActivity(intent);
	}

	/**
	 * Called when the action bar button "Search" has been clicked
	 * 
	 * @param v
	 *            the clicked button
	 */
	public void onActionBarSearchClick(View v) {
		if (Utilities.isAccountSelected(this)) {
			new SearchDialog(this).show();
		}
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		menu.clear();
		if (account != null) {
			if (account.getAccountConfiguration() != null) {
				menu.add(Menu.CATEGORY_CONTAINER, Menu.NONE, Menu.NONE,
						"Refresh configuration").setIcon(
						android.R.drawable.ic_menu_rotate);
			}
		}
		menu.add(Menu.CATEGORY_SECONDARY, Menu.NONE, Menu.NONE, "About")
				.setIcon(android.R.drawable.ic_menu_info_details);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if ("About".equals(item.getTitle())) {
			AlertDialog aboutDialog;
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setView(View.inflate(this, R.layout.about, null));
			aboutDialog = builder.create();
			aboutDialog.show();
		} else if ("Refresh configuration".equals(item.getTitle())) {
			new AccountConfigurationRequest(this, null);
		}
		return super.onOptionsItemSelected(item);
	}

}