package org.elsys.data;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import android.os.Parcel;
import android.os.Parcelable;

@JsonSerialize(include = Inclusion.NON_NULL)
public class Status implements Parcelable {

	public static enum STATUS_TYPE {
		CLOSED, OPEN
	};

	private String status;
	private String resolution;
	private List<Status> transitions;
	private STATUS_TYPE type;

	public Status(String status, STATUS_TYPE type) {
		this.status = status;
		this.type = type;
		transitions = new ArrayList<Status>();
	}

	public Status(Parcel in) {
		status = in.readString();
		resolution = in.readString();
	}

	public Status(String status, String resolution) {
		this.status = status;
		this.resolution = resolution;
	}

	public Status() {

	}

	public Status(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public STATUS_TYPE getStatusType() {
		return type;
	}

	public void setStatusType(STATUS_TYPE type) {
		this.type = type;
	}

	public List<Status> getTransitions() {
		return transitions;
	}

	public void setTransitions(List<Status> transitions) {
		this.transitions = transitions;
	}
	
	public void addTransition(Status transition) {
		transitions.add(transition);
	}

	@Override
	public String toString() {
		return status;
	}

	@Override
	public boolean equals(Object o) {
		return status.equals(o) ? true : false;
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(status);
		dest.writeString(resolution);
	}

	public static final Parcelable.Creator<Status> CREATOR = new Parcelable.Creator<Status>() {
		public Status createFromParcel(Parcel in) {
			return new Status(in);
		}

		public Status[] newArray(int size) {
			return null;
		}
	};
}
