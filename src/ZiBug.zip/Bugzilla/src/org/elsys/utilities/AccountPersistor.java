package org.elsys.utilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.elsys.AccountManager;
import org.elsys.R;
import org.elsys.data.Account;
import org.elsys.data.App;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class AccountPersistor {

	private static SharedPreferences settings;
	private static SharedPreferences.Editor editor;

	private static String encryptAccount(Account account) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		return SimpleCrypto.encrypt(mapper.writeValueAsString(account));
	}

	private static Account decryptAccount(String encryptedData)
			throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(SimpleCrypto.decrypt(encryptedData),
				Account.class);
	}

	public static void persistAccount(Context context, Account account) {
		if (account != null) {
			settings = context.getSharedPreferences(
					context.getString(R.string.shared_preferences_accounts), 0);
			editor = settings.edit();
			try {
				editor.putString(String.valueOf(account.getAccountId()),
						encryptAccount(account));
				editor.commit();
			} catch (Exception e) {
				e.printStackTrace();
				Toast.makeText(context, "Unable to store account",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	public static void persistCurrentAccount(Context context, int accountId) {
		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_current_account),
				0);
		editor = settings.edit();

		editor.putInt("id", accountId);
		editor.commit();
	}

	public static List<Account> getPersistedAccounts(Context context) {
		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_accounts), 0);
		List<Account> accounts = new ArrayList<Account>();

		try {
			@SuppressWarnings("unchecked")
			Map<String, String> data = (Map<String, String>) settings.getAll();
			Collection<String> values = data.values();
			for (String encryptedAccount : values) {
				accounts.add((Account) decryptAccount(encryptedAccount));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return accounts;
	}

	public static Account getPersistedAccount(Context context, int accountId) {
		return getAccountById(context, accountId);
	}

	private static Account getAccountById(Context context, int id) {
		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_accounts), 0);
		String result = settings.getString(String.valueOf(id), null);
		Account account = null;
		if (result != null) {
			try {
				account = decryptAccount(result);
			} catch (Exception e) {
				e.printStackTrace();
				Toast.makeText(context, "Unable to retrieve account",
						Toast.LENGTH_SHORT).show();
			}
		}
		return account;
	}

	public static Account getCurrentPersistedAccount(Context context) {

		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_current_account),
				0);
		Account account = null;
		int id = settings.getInt("id", -1);
		if (id > 0) {
			account = getAccountById(context, id);
		}
		return account;
	}

	public static void removeCurrentAccount(Context context) {
		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_current_account),
				0);
		editor = settings.edit();
		editor.clear().commit();
		
	}

	public static void deleteAccount(Context context, int id) {

		settings = context.getSharedPreferences(
				context.getString(R.string.shared_preferences_accounts), 0);
		editor = settings.edit();

		editor.remove(String.valueOf(id));
		editor.commit();
		
		AccountConfigurationPersistor.removeConfiguration(context, id);

		if (App.get().getAccount() != null
				&& App.get().getAccount().getAccountId() == id) {
			App.get().setAccount(null);
			removeCurrentAccount(context);
		}

		((AccountManager) context).loadList();

		Toast.makeText(context, "Account deleted.", Toast.LENGTH_SHORT).show();
	}
}
