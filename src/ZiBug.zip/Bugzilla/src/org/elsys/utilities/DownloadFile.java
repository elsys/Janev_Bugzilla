package org.elsys.utilities;

import java.io.File;
import java.io.FileOutputStream;

import org.elsys.R;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.StatFs;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

public class DownloadFile {

	private NotificationManager mNM;
	
	private Context context;
	private File file;
	private String fileName;
	private String data;
	private String contentType;
	
	public DownloadFile(Context context, String fileName, String data, String contentType) {
		this.context = context;
		this.fileName = fileName;
		this.data = data;
		this.contentType = contentType;
		
		mNM = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
	}
	
	public void downloadFile() {
		try {
			downloadFile(data.getBytes(), fileName);
			showNotification(fileName, "Downloaded");
		} catch(Exception e) {
			Toast.makeText(context, "File could not be saved", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void downloadFile(byte[] data, String fileName) {
		StatFs stat_fs = new StatFs(Environment.getExternalStorageDirectory()
				.getPath());
		double avail_sd_space = (double) stat_fs.getAvailableBlocks()
				* (double) stat_fs.getBlockSize();
		double MB_Available = (avail_sd_space / 1048576);
		Log.d("MB", "" + MB_Available);
		try {
			File root = new File(Environment.getExternalStorageDirectory()
					+ "/ZiBug");
			if (!root.exists() && !root.isDirectory()) {
				root.mkdir();
			}
			int fileSize = data.length / 1048578;
			System.out.println("SIZE: " + data.length);
			if(MB_Available <= fileSize) {
				showNotification("No sufficient memmory", "Error");
				return;
			}
			
			Log.d("CURRENT PATH", root.getPath());

			file = new File(root.getPath(), fileName);
			FileOutputStream f = new FileOutputStream(file);

			f.write(Base64
					.decode(data,
							Base64.NO_PADDING));
			f.flush();
			f.close();

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("Downloader", e.getMessage());
		}
	}
	
	void showNotification(String message, String title) {
		CharSequence text = message;

		Notification notification = new Notification(R.drawable.icon, "Bugzilla download",
				System.currentTimeMillis());
		notification.flags |= Notification.FLAG_AUTO_CANCEL;

		Intent intent = new Intent();
		intent.setAction(android.content.Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(file), contentType);

		System.out.println("FILE:::: " + file.getAbsolutePath());
		PendingIntent contentIntent = PendingIntent.getActivity(
				context, 0, intent,
				PendingIntent.FLAG_CANCEL_CURRENT);

		notification.setLatestEventInfo(context, title, text, contentIntent);
		mNM.notify(R.string.app_name, notification);
	}

}
